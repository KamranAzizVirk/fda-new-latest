// Limits how many chat messages one visitor (one internet address) can send.
// This protects the AI credits from bots and spam.
// Note: the counters live in the server's memory, so they are per server instance.
// For even stronger protection on Vercel, also add a Firewall rate-limit rule for /api/chat
// and a monthly spending limit on the AI Gateway.

const LIMITS = [
  { windowMs: 60_000, max: 6 }, // 6 messages per minute
  { windowMs: 60 * 60_000, max: 30 }, // 30 messages per hour
  { windowMs: 24 * 60 * 60_000, max: 60 }, // 60 messages per day
];

const LONGEST = LIMITS[LIMITS.length - 1].windowMs;
const MAX_TRACKED_VISITORS = 5000;
const hits = new Map<string, number[]>();

export function clientKey(req: Request): string {
  const h = req.headers;
  const ip =
    h.get("x-vercel-forwarded-for") ||
    h.get("x-real-ip") ||
    (h.get("x-forwarded-for") || "").split(",")[0] ||
    "unknown";
  return ip.trim().slice(0, 64);
}

/** Returns how many seconds to wait, or 0 if the message is allowed (and counts it). */
export function checkRateLimit(key: string, now = Date.now()): number {
  const list = (hits.get(key) || []).filter((t) => now - t < LONGEST);

  for (const { windowMs, max } of LIMITS) {
    const inWindow = list.filter((t) => now - t < windowMs);
    if (inWindow.length >= max) {
      hits.set(key, list);
      return Math.max(1, Math.ceil((inWindow[0] + windowMs - now) / 1000));
    }
  }

  list.push(now);
  hits.set(key, list);

  // Keep memory small: forget the oldest visitors if the list grows too big.
  if (hits.size > MAX_TRACKED_VISITORS) {
    for (const k of hits.keys()) {
      hits.delete(k);
      if (hits.size <= MAX_TRACKED_VISITORS * 0.8) break;
    }
  }
  return 0;
}
