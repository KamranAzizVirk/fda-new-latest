"use client";

// Google login with Supabase Auth.
// The Supabase code (about 50 KB) is downloaded ONLY when a visitor clicks Login, is already logged in,
// or posts a comment, so normal visitors keep the same page speed.
// Settings come from Vercel: NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY (public "anon" key only).

import type { SupabaseClient } from "@supabase/supabase-js";
import { useSyncExternalStore } from "react";

export const SUPABASE_URL = (process.env.NEXT_PUBLIC_SUPABASE_URL || "").replace(/\/+$/, "");
export const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "";
export const AUTH_READY = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);

export type AuthUser = { id: string; name: string; avatar: string | null };
type AuthState = { status: "loading" | "out" | "in"; user: AuthUser | null };

let state: AuthState = { status: "loading", user: null };
const listeners = new Set<() => void>();
const set = (next: AuthState) => {
  state = next;
  listeners.forEach((l) => l());
};

let clientPromise: Promise<SupabaseClient | null> | null = null;
export function getSupabase(): Promise<SupabaseClient | null> {
  if (!AUTH_READY) return Promise.resolve(null);
  clientPromise ??= import("@supabase/supabase-js")
    .then(({ createClient }) => {
      const client = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
        auth: { flowType: "implicit", persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
      });
      client.auth.onAuthStateChange((_event, session) => set(fromSession(session?.user)));
      return client;
    })
    .catch(() => {
      clientPromise = null;
      return null;
    });
  return clientPromise;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function fromSession(u: any): AuthState {
  if (!u) return { status: "out", user: null };
  const m = u.user_metadata || {};
  const avatar = typeof (m.avatar_url || m.picture) === "string" && /^https:\/\//.test(m.avatar_url || m.picture) ? m.avatar_url || m.picture : null;
  return { status: "in", user: { id: u.id, name: String(m.full_name || m.name || u.email || "User").slice(0, 80), avatar } };
}

// True when this browser has a saved login, or is just coming back from the Google login page.
function maybeLoggedIn() {
  try {
    if (/access_token=|error_description=/.test(window.location.hash)) return true;
    return Object.keys(window.localStorage).some((k) => k.startsWith("sb-") && k.endsWith("-auth-token"));
  } catch {
    return false;
  }
}

let started = false;
/** Called once by the header. Loads Supabase only if this visitor may already be logged in. */
export function startAuth() {
  if (started) return;
  started = true;
  if (!AUTH_READY || !maybeLoggedIn()) {
    set({ status: "out", user: null });
    return;
  }
  getSupabase().then(async (sb) => {
    if (!sb) return set({ status: "out", user: null });
    const { data } = await sb.auth.getSession();
    set(fromSession(data.session?.user));
  });
}

export async function signInWithGoogle() {
  const sb = await getSupabase();
  if (!sb) throw new Error("not-ready");
  const back = window.location.origin + window.location.pathname;
  const { error } = await sb.auth.signInWithOAuth({ provider: "google", options: { redirectTo: back } });
  if (error) throw error;
}

export async function signOut() {
  const sb = await getSupabase();
  await sb?.auth.signOut();
  set({ status: "out", user: null });
}

export function useAuth(): AuthState {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => state,
    () => state
  );
}

/* ---- Login box (opened from the header button or the comments box) ---- */
let loginOpen = false;
const loginListeners = new Set<() => void>();
export function setLoginOpen(v: boolean) {
  loginOpen = v;
  loginListeners.forEach((l) => l());
}
export function useLoginOpen() {
  return useSyncExternalStore(
    (l) => {
      loginListeners.add(l);
      return () => loginListeners.delete(l);
    },
    () => loginOpen,
    () => false
  );
}
