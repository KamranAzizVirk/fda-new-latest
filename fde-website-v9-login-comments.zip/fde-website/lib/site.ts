export const SITE = {
  name: "FDE - AI Automation Agency",
  headerName: "FDE - AI Automation Agency",
  url: "https://www.fdeautomation.com",
  email: "contact@fdeautomation.com",
  phoneDisplay: "+92 321 3322676",
  phoneIntl: "+923213322676",
  whatsappNumber: "923213322676",
  linkedin: "https://www.linkedin.com/in/kamran-aziz-69b9651a0",
  founder: "Kamran Aziz",
  founderTitle: "Founder of FDE - AI Automation Agency",
  city: "Faisalabad",
  country: "Pakistan",
  title: "FDE - AI Automation Agency | AI Agents and Business Automation for Small and Medium Businesses",
  description:
    "FDE - AI Automation Agency builds AI voice agents, chat agents, n8n and WhatsApp automation, and websites for small and medium businesses. We learn how your business runs, build the system that fits it, and support it after launch.",
} as const;

export function waLink(text?: string) {
  const base = `https://wa.me/${SITE.whatsappNumber}`;
  return text ? `${base}?text=${encodeURIComponent(text)}` : base;
}

export const BOOK_CALL_URL = waLink("Hi FDE - AI Automation Agency, I'd like to book a free call and get a custom quote.");
export const HELLO_URL = waLink("Hi FDE - AI Automation Agency, I'd like to know more about your services.");

export const NAV = [
  { label: "Home", href: "/" },
  { label: "CEO Message", href: "/ceo-message" },
  { label: "Projects", href: "/projects" },
  { label: "About Me", href: "/about" },
  { label: "Services", href: "/services" },
  { label: "Team", href: "/#team" },
  { label: "Contact", href: "/contact" },
] as const;
