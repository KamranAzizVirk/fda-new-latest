// All website copy, approved tab by tab by Kamran Aziz on 2026-11-14.
// The AI chat agent and the structured data read from this same file,
// so editing a line here updates every place it appears.

export type IconName =
  | "voice" | "flow" | "target" | "sheet" | "design" | "screen"
  | "search" | "plan" | "build" | "support" | "phone" | "clock" | "copy"
  | "shield" | "spark" | "globe" | "check" | "mail" | "calendar" | "pin";

/* ---------------- HOME ---------------- */
export const HOME = {
  label: "For small and medium businesses",
  // Headline changed 2026-11-17 at Kamran's request.
  // Old headline (saved, can be restored): "Never miss another [call. / lead. / deal.]" with the last word rotating.
  headlineBefore: "I Build AI Agents That Work",
  headlineHighlight: "24/7",
  headlineAfter: "For Your Business",
  // Hero refined 2026-11-17 (improve2) at Kamran's request. Headline words are the same; only the line breaks are set here.
  // Capital letters changed 2026-11-17 at Kamran's request. Before (saved): "I Build AI Agents", "That Work", "For Your Business".
  headlineLines: ["I build AI Agents", "that work", "for your Business"], // "24/7" (headlineHighlight) sits at the end of line 2
  // Old paragraph (saved, can be restored): "AI agents and automation that work for your business 24/7. We learn how your business runs, build the system that fits it, and stay with you after launch."
  sub: "AI voice agents, chat agents, and workflow automation that help your business respond faster, capture leads, and reduce repetitive work.",
  // Old check points (saved, can be restored): "Built around your business", "Works with the tools you already use", "Support after launch"
  // These three are positioning statements, not certifications or awards.
  trust: [
    { icon: "shield", text: "Trusted Automation" },
    { icon: "clock", text: "24/7 AI Agents" },
    { icon: "globe", text: "Built for Growing Businesses" }, // Before (saved): "Built for US Businesses". Changed 2026-11-17 at Kamran's request.
  ] as const,
  founderLine: { name: "Kamran Aziz", title: "Founder & CEO" },
  problem: {
    heading: "Busy businesses lose customers in small ways.",
    items: [
      { icon: "phone" as IconName, text: "A call comes in after hours, and no one answers." },
      { icon: "clock" as IconName, text: "A new lead waits too long for a reply and goes to someone else." },
      { icon: "copy" as IconName, text: "Your team spends hours copying data from one app to another." },
    ],
    closing: "Automation closes these gaps, so you can focus on the work that grows your business.",
  },
  whatWeDo: {
    heading: "One team for your AI agents, workflows, and website.",
    items: [
      { icon: "voice" as IconName, title: "AI voice and chat agents", text: "answer calls and messages, day and night." },
      { icon: "flow" as IconName, title: "n8n and WhatsApp automation", text: "your apps work together by themselves." },
      { icon: "target" as IconName, title: "Lead generation, CRM, and email", text: "follow up with every lead, on time." },
      { icon: "sheet" as IconName, title: "Google Sheets, Gmail, and Calendar", text: "less copy and paste, more done." },
      { icon: "design" as IconName, title: "Web design", text: "a clean, modern look that builds trust." },
      { icon: "screen" as IconName, title: "Website and mobile apps", text: "fast, with automation built in." },
    ],
  },
  howWeWork: {
    heading: "Simple process. Real support.",
    steps: [
      { icon: "search" as IconName, title: "Understand", text: "We study how your business runs, in strict confidence." },
      { icon: "plan" as IconName, title: "Design", text: "We plan the right solution and send you a custom quote." },
      { icon: "build" as IconName, title: "Build", text: "We set it up, test it with real scenarios, and launch it." },
      { icon: "support" as IconName, title: "Support", text: "We stay with you after launch and fix anything that needs fixing." },
    ],
  },
  featured: {
    heading: "Estimator Pro: a construction estimate app.",
    text: "Enter plot details and get a full estimate: cost, materials, labor, timeline, and PDF reports.",
    // Wording changed to "Demo project" on 2026-11-17 while the demo link is hidden. Original: "Live demo. All numbers inside are sample data."
    note: "Demo project. All numbers inside are sample data.",
  },
  why: {
    heading: "We build it, and we stay with it.",
    items: [
      { title: "We learn your business first.", text: "Automation works best when it fits how you really work." },
      { title: "Honest pricing.", text: "You get a custom quote before any work starts. No surprise bills." },
      { title: "Help after launch.", text: "If something stops working, we fix it." },
      { title: "Remote, worldwide.", text: "Based in Faisalabad, Pakistan. Working with clients in the USA and beyond." },
    ],
  },
  closing: {
    heading: "Ready to stop losing leads?",
    text: "Book a call and get a custom quote for your business.",
  },
};

/* ---------------- CEO MESSAGE ---------------- */
export const CEO = {
  label: "A message from our founder",
  heading: "Your business deserves a partner you can trust.",
  intro: [
    "Hello, and thank you for visiting FDE - AI Automation Agency.",
    "My name is Kamran Aziz. I am the Founder and CEO of FDE - AI Automation Agency, based in Faisalabad, Pakistan.",
    "I started FDE with one simple goal: to help small and medium businesses save time and stop losing customers. Many business owners work long hours, miss calls, and spend too much time on tasks a computer can do. We are here to change that.",
    "When you work with us, here is my promise to you:",
  ],
  promises: [
    { icon: "shield" as IconName, title: "Trust.", text: "We treat your business information with full respect and keep it private. We are honest about what we can do, and we tell you the truth, even when it is not what you want to hear." },
    { icon: "spark" as IconName, title: "Quality.", text: "We do not use one plan for everyone. We first learn how your business works, then build a system that fits you. Every system is tested before it goes live." },
    { icon: "calendar" as IconName, title: "On-time delivery.", text: "Before we start, we agree on a clear timeline. We keep you updated at every step, so you always know where your project stands." },
    { icon: "globe" as IconName, title: "USA standard.", text: "We work to the standard American businesses expect: clear communication, fast replies, and work done right the first time. We meet on video calls at a time that suits your time zone." },
  ],
  outro: [
    "Our work does not end when your system goes live. We stay with you after launch. If something needs a fix or a change, we are just one message away.",
    "I would be happy to learn about your business and show you what automation can do for you.",
  ],
  signoff: "Thank you,",
};

/* ---------------- PROJECTS ---------------- */
export const PROJECTS = {
  label: "Projects",
  heading: "See what we build.",
  // Original (restore when the demo link is back): "One live project you can try today, plus examples of systems we build for small and medium businesses."
  intro: "One demo project, plus examples of systems we build for small and medium businesses.",
  live: {
    title: "Estimator Pro: construction estimate app",
    problem: "Builders spend hours working out costs, materials, and timelines by hand for every new client.",
    solution: "A web app that turns plot details into a full estimate in 7 simple steps: cost, material quantities, labor, a stage-by-stage timeline, and PDF reports for the client and the contractor.",
    result: "Gives a clear, professional estimate in minutes instead of hours.",
    // Original: "Live demo. All numbers, reviews, and contact details inside are sample data."
    note: "Demo project. All numbers, reviews, and contact details inside are sample data.",
    url: "https://fda-construction-app.vercel.app/",
    // The "Open live demo" buttons are HIDDEN (2026-11-17) because the address above
    // currently shows the wrong site. When the Estimator Pro app is back online,
    // put its new address in "url" above and change this line to: showDemoButton: true
    showDemoButton: false,
  },
  examplesHeading: "Example solutions",
  examplesSub: "What we can build for your business",
  examples: [
    {
      icon: "phone" as IconName,
      title: "AI receptionist for service businesses",
      problem: "Plumbers, contractors, and repair companies miss calls while they are on a job. Each missed call can be a lost customer.",
      solution: "An AI voice agent that answers every call, answers common questions, collects the customer's details, and books the job on your calendar.",
      builtTo: "Answer every call, 24/7, and send you a short summary after each one.",
    },
    {
      icon: "target" as IconName,
      title: "Lead follow-up for real estate agents",
      problem: "Online leads go cold when no one replies within minutes.",
      solution: "An automation that replies to new leads on WhatsApp, text, or email right away, asks a few key questions, and books a viewing. Every lead is saved in your CRM.",
      builtTo: "Reply in minutes, follow up on schedule, and never forget a lead.",
    },
    {
      icon: "calendar" as IconName,
      title: "Appointment booking for clinics",
      problem: "Front desk staff spend hours on the phone booking and moving appointments, and some patients do not show up.",
      solution: "An AI chat and voice agent that books, moves, and cancels appointments, plus automatic reminders before each visit.",
      builtTo: "Take bookings day and night and remind patients before they come.",
    },
    {
      icon: "voice" as IconName,
      title: "Order updates for online stores",
      problem: "Customers keep asking, “Where is my order?”, and your team answers the same question all day.",
      solution: "A WhatsApp and website chat agent connected to your store that gives order status, answers common questions, and passes hard cases to your team.",
      builtTo: "Answer repeat questions instantly so your team can focus on real problems.",
    },
  ],
  closing: {
    heading: "Have a different problem?",
    text: "Every business is different. Tell us what slows you down, and we will design the right solution.",
  },
};

/* ---------------- ABOUT ME ---------------- */
export const ABOUT = {
  label: "About Me",
  heading: "Hi, I’m Kamran Aziz.",
  sub: "Founder of FDE - AI Automation Agency.",
  story: {
    heading: "Our story",
    paragraphs: [
      "FDE - AI Automation Agency started with a simple idea: small and medium businesses should get the same smart tools that big companies use.",
      "Big companies have teams of engineers to automate their work. Most small businesses do not. Their owners answer calls, chase leads, send reminders, and type the same data again and again, often late into the night.",
      "I started FDE - AI Automation Agency in Faisalabad, Pakistan, to change that. We build AI agents and automation systems that take this daily work off your plate, so you can focus on your customers and grow your business.",
    ],
  },
  fde: {
    heading: "What “FDE” means",
    lead: "FDE stands for Forward Deployed Engineer.",
    text: "A forward deployed engineer does not just hand you a tool and walk away. They work closely with you, inside your real business problem, until it is solved. That is how we work with every client.",
  },
  beliefs: {
    heading: "What we believe",
    items: [
      { icon: "search" as IconName, title: "Understand first, build second.", text: "We learn how your business really works before we suggest anything." },
      { icon: "shield" as IconName, title: "Keep it private.", text: "Your business information stays between us." },
      { icon: "spark" as IconName, title: "Keep it simple.", text: "Automation should make your day easier, not harder." },
      { icon: "support" as IconName, title: "Stay after launch.", text: "Our work is done when your system keeps working for you, not on launch day." },
    ],
  },
  who: {
    heading: "Who we work with",
    text: "Small and medium businesses of every type, in the USA, Europe, and around the world. If your business loses time on repeat tasks or loses customers because of slow replies, we can help.",
  },
  how: {
    heading: "How we work with you",
    text: "Everything is remote. We meet on video calls at a time that suits your time zone, and you can reach us on WhatsApp and email throughout your project.",
  },
  closing: "Let’s talk about your business.",
};

/* ---------------- SERVICES ---------------- */
export const SERVICES_PAGE = {
  label: "Services",
  heading: "Automation that fits your business.",
  intro: "We build AI agents, workflows, and websites that save you time and help you win more customers. Every service comes with support after launch.",
  includesHeading: "Every service includes:",
  includes: [
    "A free first call to understand your business",
    "A custom quote before any work starts",
    "Testing with real scenarios before launch",
    "Support after launch",
  ],
  closing: {
    heading: "Not sure which service you need?",
    text: "Tell us what slows your business down, and we will suggest the right solution.",
  },
};

/**
 * The 4 main services shown at the top of the Services page (added 2026-11-17, improve3).
 * The three "points" on the FDE card are the old Hero check points Kamran asked to keep.
 * No measured numbers or guarantees here.
 */
export const CORE_SERVICES = {
  eyebrow: "Core services",
  heading: "Four ways we put AI to work for you.",
  items: [
    {
      id: "voice",
      title: "AI Voice Agents",
      text: "AI phone agents that answer every call right away and book appointments, so you stop losing leads to missed calls.",
    },
    {
      id: "chat",
      title: "AI Chat Agents",
      text: "AI chat agents that reply instantly on your website, answer questions, and capture leads 24/7.",
    },
    {
      id: "flow",
      title: "Workflow Automation",
      text: "We connect your tools and automate repetitive work, so your team saves hours every week.",
    },
  ],
  fde: {
    id: "fde",
    title: "FDE - Forward Deployed Engineer Services",
    text: "We work inside your business like your own AI team. First we understand what you need, then we build the system, launch it, and support it after launch.",
    points: ["Built around your business", "Works with the tools you already use", "Support after launch"],
  },
  moreHeading: "Everything we can build for you",
  moreText: "A closer look at each area of work.",
} as const;

export const SERVICES = [
  {
    icon: "voice" as IconName,
    title: "AI voice and chat agents",
    tagline: "Never let a call or message go unanswered again.",
    points: [
      "An AI voice agent that answers your phone, talks naturally, and books meetings",
      "A chat agent for your website and WhatsApp",
      "Trained on your services, hours, and common questions",
      "Passes the conversation to you when a person is needed",
      "A short summary of every call and chat",
    ],
    goodFor: "businesses that miss calls or get many repeat questions.",
  },
  {
    icon: "flow" as IconName,
    title: "n8n and WhatsApp automation",
    tagline: "Let your apps do the work while you focus on your customers.",
    points: [
      "Custom n8n workflows that connect your apps",
      "Automatic WhatsApp Business replies, updates, and reminders",
      "Data moves between your tools by itself, with no copy and paste",
      "Alerts if something stops working",
    ],
    goodFor: "teams that spend hours moving data or sending the same messages.",
  },
  {
    icon: "target" as IconName,
    title: "Lead generation, CRM, and email",
    tagline: "Find more leads and follow up with every one.",
    points: [
      "Find and reach new leads",
      "Track every reply in one place",
      "Automatic follow-ups until the lead answers",
      "CRM setup with HubSpot or GoHighLevel",
      "Email automation for offers, updates, and reminders",
    ],
    goodFor: "businesses where leads slip through the cracks.",
  },
  {
    icon: "sheet" as IconName,
    title: "Google Sheets, Gmail, and Calendar automation",
    tagline: "Make the Google tools you already use work together.",
    points: [
      "New leads and orders saved to Google Sheets automatically",
      "Automatic Gmail replies, alerts, and reports",
      "Meetings booked straight onto Google Calendar",
      "Daily or weekly reports that build themselves",
    ],
    goodFor: "small teams that run their business on Google tools.",
  },
  {
    icon: "design" as IconName,
    title: "Web design",
    tagline: "A modern look that makes people trust you.",
    points: [
      "Clean, professional website and landing page design",
      "Designed for phones first",
      "Clear buttons that turn visitors into calls and inquiries",
      "A look that matches your brand",
    ],
    goodFor: "businesses with an old website, or no website yet.",
  },
  {
    icon: "screen" as IconName,
    title: "Website and mobile app development",
    tagline: "Fast websites and apps, with automation built in.",
    points: [
      "Website development",
      "Mobile app development",
      "Contact forms, chat, and booking connected from day one",
      "Fast loading and easy for Google to find",
    ],
    goodFor: "businesses that need a new website, a customer app, or an internal tool.",
  },
];

/* ---------------- CONTACT ---------------- */
export const CONTACT = {
  label: "Contact",
  heading: "Let’s talk about your business.",
  intro: "Tell us what you want to automate. We will reply with next steps and a custom quote. The first call is free.",
  formHeading: "Send us a message",
  formNote: "Your message opens in WhatsApp or your email app, ready to send.",
  otherHeading: "Other ways to reach us",
  location: "Faisalabad, Pakistan. We work remotely with clients in the USA, Europe, and around the world.",
  videoNote: "We meet on video calls at a time that suits your time zone.",
  faqHeading: "Frequently asked questions",
  closing: "Ready when you are.",
};

export const FAQ = [
  { q: "What does FDE - AI Automation Agency do?", a: "We help small and medium businesses automate their work. We build AI voice agents, chat agents, and automation workflows that answer calls and messages, follow up with leads, book meetings, and keep your CRM, sheets, and inbox up to date. We also design and build websites and mobile apps." },
  { q: "Do you work with my type of business?", a: "Yes. We work with small and medium businesses of every type. Before we build anything, we learn how your business runs, so the system fits the way you work." },
  { q: "How much does it cost?", a: "Every business is different, so we do not have fixed packages. Book a call, and we will send you a custom quote before any work starts." },
  { q: "How long does a project take?", a: "It depends on what we build. You get a clear timeline with your quote, and we keep you updated at every step." },
  { q: "What happens after my system goes live?", a: "We stay with you. If something stops working or your business needs a change, send us a message and we will take care of it." },
  { q: "Will it work with the tools I already use?", a: "In most cases, yes. We often connect phone systems, WhatsApp, Google Workspace, CRMs, and calendars. If a tool can connect to other apps, we can usually work with it." },
  { q: "Will the AI agent sound natural to my customers?", a: "Yes. Modern AI agents handle normal conversations well. We write the script with you, test it with real scenarios, and send customers to a real person whenever that is the better choice." },
  { q: "Is my business information kept private?", a: "Yes. We only use what the project needs, work in your own accounts when we can, and never share your information with anyone outside the project." },
  { q: "You are in Pakistan. How do we work together?", a: "Everything is remote. We meet on video calls at a time that suits your time zone, and you can reach us on WhatsApp and email anytime during your project." },
];

// Add real client reviews here when you have them. Nothing shows on the site while this list is empty.
export const TESTIMONIALS: { quote: string; name: string; role: string }[] = [];

/* ---------------- NEW FEATURES (added 2026-11-14, copy waiting for Kamran's OK) ---------------- */

/** Trust badges: ONLY honest commitments Kamran approved on 2026-11-14. No awards, certifications or client counts. */
export const TRUST_BADGES: { icon: IconName; text: string }[] = [
  { icon: "phone", text: "Free first call" },
  { icon: "plan", text: "Custom quote before work starts" },
  { icon: "shield", text: "Your data stays private" },
  { icon: "check", text: "Tested before launch" },
  { icon: "support", text: "Support after launch" },
  { icon: "globe", text: "Remote, worldwide" },
];

/** Missed-call (ROI) calculator. Uses ONLY the visitor's own numbers. No FDE results are claimed. */
export const ROI = {
  eyebrow: "Missed-call calculator",
  heading: "How much are missed calls costing you?",
  intro: "Enter your own numbers to see a rough estimate of the revenue you may be losing to missed calls and slow replies.",
  fields: {
    missed: { label: "Missed calls or late replies per week", min: 0, max: 200, step: 1, start: 10 },
    rate: { label: "How many would become customers (%)", min: 0, max: 100, step: 1, start: 20 },
    value: { label: "Average value of one new customer (USD)", min: 0, max: 50000, step: 50, start: 500 },
  },
  startNote: "The starting numbers are only an example. Change them to match your business.",
  resultLabel: "Estimated revenue lost",
  perMonth: "per month",
  perYear: "per year",
  disclaimer: "This is a rough estimate based only on the numbers you enter. It is not a promise of results.",
  button: "Book a Call",
};

/** Project filter on the Projects page. */
export type ProjectTag = "live" | "agents" | "leads" | "booking";
export const PROJECT_FILTERS: { id: "all" | ProjectTag; label: string }[] = [
  { id: "all", label: "All" },
  { id: "live", label: "Demo project" }, // Original label: "Live demo"
  { id: "agents", label: "Voice & chat agents" },
  { id: "leads", label: "Lead follow-up" },
  { id: "booking", label: "Booking" },
];
/** Tags for each project, in the same order as PROJECTS.examples. The live project is always "live". */
export const EXAMPLE_TAGS: ProjectTag[][] = [
  ["agents", "booking"], // AI receptionist: answers calls, books jobs
  ["leads", "booking"], // Real estate lead follow-up: replies, books viewings
  ["agents", "booking"], // Clinic booking: chat + voice agent, bookings
  ["agents"], // Order updates: WhatsApp + website chat agent
];
