// =====================================================================
//  LEADERSHIP TEAM  -  the only file you need to edit for the team.
//
//  To change director, only edit Name and Photo link here.
//  You can put a photo or keep the icon.
//
//  HOW TO EDIT
//  - name:  write the person's name between the quotes.
//  - title: the job title shown under the name.
//  - photo: leave as "" to show the neutral icon.
//           To show a photo, either
//             (a) put the photo file in the "public" folder and write
//                 its name with a slash, for example "/sara.jpg", or
//             (b) paste a full photo link, for example
//                 "https://example.com/photo.jpg".
//           Square photos look best (for example 400 x 400).
//  - To add a director: copy one { ... } block, paste it below the
//    last one, and change the text.
//  - To remove a director: delete that { ... } block.
// =====================================================================

export const TEAM_HEADING = "Meet Our Leadership Team";

// ---------- CEO (do not change unless the CEO changes) ----------
export const CEO_MEMBER = {
  name: "Kamran Aziz",
  title: "FOUNDER & CEO",
  photo: "/kamran-aziz.jpg",
};

// ---------- DIRECTORS ----------
export const DIRECTORS = [
  {
    name: "Name to be added",
    title: "DIRECTOR FDE",
    photo: "",
  },
  {
    name: "Name to be added",
    title: "DIRECTOR OPERATIONS",
    photo: "",
  },
  {
    name: "Name to be added",
    title: "DIRECTOR GRAPHIC & DESIGNING",
    photo: "",
  },
  {
    name: "Name to be added",
    title: "DIRECTOR AI",
    photo: "",
  },
];
