import Link from "next/link";
import { HOME, PROJECTS, ROI } from "@/lib/content";
import { Icon } from "@/components/Icon";
import { Reveal } from "@/components/Reveal";
import { Rise } from "@/components/Rise";
import { HeroRobot } from "@/components/HeroRobot";
import { FounderPhoto } from "@/components/FounderPhoto";
import { ToolsStrip } from "@/components/ToolsStrip";
import { TrustBadges } from "@/components/TrustBadges";
import { RoiSection } from "@/components/RoiSection";
import { TeamSection } from "@/components/TeamSection";
import { CommentsSection } from "@/components/CommentsSection";
import { BookCallButton, CtaBand, Eyebrow, TextLink } from "@/components/ui";
import { HOME_HERO_CSS } from "./home-hero.css";

export default function HomePage() {
  return (
    <>
      {/* Hero */}
      <section className="hh-section overflow-hidden pt-12 pb-14 lg:pt-20 lg:pb-24">
        <style>{HOME_HERO_CSS}</style>
        <div className="wrap grid items-center gap-11 lg:grid-cols-[1.12fr_.88fr] lg:gap-16">
          <div>
            <Rise>
              <span className="mb-6 inline-flex items-center gap-2 rounded-full border border-line bg-card px-3.5 py-1.5 text-[.82rem] text-mut">
                <i className="live-dot" />{HOME.label}
              </span>
            </Rise>
            <Rise delay={0.05}>
              <h1 className="hh-title">
                <span className="hh-line">{HOME.headlineLines[0]}</span>{" "}
                <span className="hh-line">{HOME.headlineLines[1]} <span className="hl">{HOME.headlineHighlight}</span></span>{" "}
                <span className="hh-line">{HOME.headlineLines[2]}</span>
              </h1>
            </Rise>
            <Rise delay={0.1}><p className="hh-sub">{HOME.sub}</p></Rise>
            <Rise delay={0.15}>
              <ul className="hh-trust">
                {HOME.trust.map((t) => (
                  <li key={t.text}><Icon name={t.icon} className="h-[17px] w-[17px]" />{t.text}</li>
                ))}
              </ul>
            </Rise>
            <Rise delay={0.2}>
              <div className="hh-actions">
                <BookCallButton className="btn btn-gold hh-primary" />
                <Link href="/projects" className="btn btn-outline hh-secondary">See Our Projects</Link>
              </div>
            </Rise>
            <Rise delay={0.25}>
              <div className="hh-founder">
                <FounderPhoto size={48} />
                <p><strong>{HOME.founderLine.name}</strong> <span aria-hidden="true">-</span> <span>{HOME.founderLine.title}</span></p>
              </div>
            </Rise>
          </div>
          <Rise delay={0.15}>
            {/* Robot on all screens (phones + desktop). Old "Lead to booked meeting" card (WorkflowCard) removed from the Hero. */}
            <HeroRobot />
          </Rise>
        </div>
        {/* Trust badges: honest commitments only */}
        <div className="wrap mt-12 lg:mt-16">
          <TrustBadges />
        </div>
      </section>

      {/* The problem */}
      <section className="bg-bg2 py-16 lg:py-24">
        <div className="wrap">
          <Reveal className="max-w-2xl"><Eyebrow>The problem</Eyebrow><h2 className="text-[clamp(1.8rem,4.8vw,2.65rem)]">{HOME.problem.heading}</h2></Reveal>
          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {HOME.problem.items.map((p, i) => (
              <Reveal key={p.text} delay={i * 0.08} className="group rounded-[18px] border border-line bg-card p-6">
                <span className="mb-4 grid h-11 w-11 place-items-center rounded-xl bg-[#FBE9E4] text-[#B4472C]"><Icon name={p.icon} animate /></span>
                <p className="text-[1.02rem] font-medium">{p.text}</p>
              </Reveal>
            ))}
          </div>
          <Reveal><p className="mt-8 max-w-2xl text-[1.05rem] text-mut">{HOME.problem.closing}</p></Reveal>
        </div>
      </section>

      {/* Missed-call (ROI) calculator */}
      <section id="calculator" className="py-16 lg:py-24">
        <div className="wrap">
          <Reveal className="max-w-2xl">
            <Eyebrow>{ROI.eyebrow}</Eyebrow>
            <h2 className="text-[clamp(1.8rem,4.8vw,2.65rem)]">{ROI.heading}</h2>
            <p className="mt-4 text-[1.05rem] text-mut">{ROI.intro}</p>
          </Reveal>
          <div className="mt-10"><RoiSection /></div>
        </div>
      </section>

      {/* What we do */}
      <section className="bg-bg2 py-16 lg:py-24">
        <div className="wrap">
          <Reveal className="max-w-2xl"><Eyebrow>What we do</Eyebrow><h2 className="text-[clamp(1.8rem,4.8vw,2.65rem)]">{HOME.whatWeDo.heading}</h2></Reveal>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {HOME.whatWeDo.items.map((s, i) => (
              <Reveal key={s.title} delay={(i % 3) * 0.08} className="card-lift group rounded-[18px] border border-line bg-card p-6">
                <span className="mb-4 grid h-[46px] w-[46px] place-items-center rounded-[13px] bg-gold-l text-gold-d"><Icon name={s.icon} className="h-[22px] w-[22px]" animate /></span>
                <h3 className="text-[1.05rem] font-semibold">{s.title}</h3>
                <p className="mt-1.5 text-[.95rem] text-mut">{s.text.charAt(0).toUpperCase() + s.text.slice(1)}</p>
              </Reveal>
            ))}
          </div>
          <Reveal className="mt-8"><TextLink href="/services">See all services</TextLink></Reveal>
        </div>
      </section>

      <TeamSection />

      {/* How we work */}
      <section className="py-16 lg:py-24">
        <div className="wrap">
          <Reveal className="max-w-2xl"><Eyebrow>How we work</Eyebrow><h2 className="text-[clamp(1.8rem,4.8vw,2.65rem)]">{HOME.howWeWork.heading}</h2></Reveal>
          <ol className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {HOME.howWeWork.steps.map((s, i) => (
              <li key={s.title}>
                <Reveal delay={i * 0.08} className="h-full rounded-[18px] border border-line bg-card p-6">
                  <div className="mb-4 flex items-center justify-between">
                    <span className="rounded-full bg-gold-l px-2.5 py-1.5 text-[.78rem] font-semibold tracking-[.1em] text-gold-d">0{i + 1}</span>
                    <Icon name={s.icon} className="h-6 w-6 text-gold-d" animate />
                  </div>
                  <h3 className="text-[1.05rem] font-semibold">{s.title}</h3>
                  <p className="mt-1.5 text-[.95rem] text-mut">{s.text}</p>
                </Reveal>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <ToolsStrip />

      {/* Featured project */}
      <section className="py-16 lg:py-24">
        <div className="wrap">
          <Reveal className="grid overflow-hidden rounded-[26px] bg-ink text-[#F6F1E6] lg:grid-cols-[1.15fr_.85fr]">
            <div className="px-6 py-9 md:px-10 md:py-11">
              <Eyebrow dark>Featured project &middot; Demo project</Eyebrow>
              <h2 className="text-[clamp(1.7rem,4.6vw,2.5rem)]">{HOME.featured.heading}</h2>
              <p className="mt-4 text-[#C9C2B3]">{HOME.featured.text}</p>
              <div className="mt-7 flex flex-wrap gap-3">
                {PROJECTS.live.showDemoButton && (
                  <a href={PROJECTS.live.url} target="_blank" rel="noopener noreferrer" className="btn bg-gold-on-dark text-ink hover:bg-[#E8C676]">Open live demo <span aria-hidden="true">&rarr;</span></a>
                )}
                <Link href="/projects" className="btn border-[#5a544a] text-[#F6F1E6] hover:border-[#F6F1E6]">See all projects <span aria-hidden="true">&rarr;</span></Link>
              </div>
              <p className="mt-4 text-[.82rem] text-[#A8A091]">{HOME.featured.note}</p>
            </div>
            <div aria-hidden="true" className="grid content-center gap-2.5 bg-[#242220] p-6 md:p-9">
              <div className="mb-1 flex items-center justify-between text-[.9rem] font-semibold">
                <span>Estimator Pro</span>
                <b className="rounded-full bg-gold-on-dark px-2.5 py-1.5 text-[.66rem] uppercase tracking-[.08em] text-ink">Demo data</b>
              </div>
              <div className="mb-2 h-1.5 overflow-hidden rounded bg-[#3A362E]"><i className="block h-full w-[72%] rounded bg-gold-on-dark" /></div>
              {[["Plot size and design", "Step 1–2"], ["Materials and labor", "Step 3–4"], ["Finishing and timeline", "Step 5–6"], ["Final report (PDF)", "Step 7"]].map(([a, b]) => (
                <div key={a} className="flex items-center justify-between gap-3 rounded-[14px] border border-[#3A362E] bg-[#2E2B27] px-4 py-3.5 text-[.9rem]">
                  {a}<b className="whitespace-nowrap text-[.8rem] font-medium text-gold-on-dark">{b}</b>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* Why FDE */}
      <section className="bg-bg2 py-16 lg:py-24">
        <div className="wrap">
          <Reveal className="max-w-2xl"><Eyebrow>Why FDE</Eyebrow><h2 className="text-[clamp(1.8rem,4.8vw,2.65rem)]">{HOME.why.heading}</h2></Reveal>
          <div className="mt-10 grid gap-4 sm:grid-cols-2">
            {HOME.why.items.map((w, i) => (
              <Reveal key={w.title} delay={(i % 2) * 0.08} className="flex gap-4 rounded-[18px] border border-line bg-card p-6">
                <Icon name="check" className="mt-0.5 h-6 w-6 flex-none text-gold-d" />
                <div><h3 className="font-semibold">{w.title}</h3><p className="mt-1 text-[.95rem] text-mut">{w.text}</p></div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <CtaBand heading={HOME.closing.heading} text={HOME.closing.text} />

      {/* Comments (Home page only, just above the footer) */}
      <CommentsSection />
    </>
  );
}
