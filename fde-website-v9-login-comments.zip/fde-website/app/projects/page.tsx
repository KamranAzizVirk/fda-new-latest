import type { Metadata } from "next";
import { PROJECTS } from "@/lib/content";
import { ProjectsBrowser } from "@/components/ProjectsBrowser";
import { CtaBand, PageHero } from "@/components/ui";

export const metadata: Metadata = {
  title: "Projects",
  description: "See Estimator Pro, a live construction estimate app, and example AI automation solutions FDE - AI Automation Agency builds for small and medium businesses.",
  alternates: { canonical: "/projects" },
};

export default function ProjectsPage() {
  return (
    <>
      <PageHero label={PROJECTS.label} heading={PROJECTS.heading} intro={PROJECTS.intro} />
      <ProjectsBrowser />
      <CtaBand heading={PROJECTS.closing.heading} text={PROJECTS.closing.text} secondary="none" />
    </>
  );
}
