import type { MetadataRoute } from "next";
import { NAV, SITE } from "@/lib/site";

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  return [
    ...NAV.filter((n) => !n.href.includes("#")).map((n) => ({ url: `${SITE.url}${n.href === "/" ? "" : n.href}`, lastModified: now, priority: n.href === "/" ? 1 : 0.8 })),
    { url: `${SITE.url}/privacy`, lastModified: now, priority: 0.3 },
  ];
}
