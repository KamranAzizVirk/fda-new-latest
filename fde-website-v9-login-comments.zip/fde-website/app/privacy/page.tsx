import type { Metadata } from "next";
import { SITE } from "@/lib/site";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "How FDE - AI Automation Agency handles the information you share through this website.",
  alternates: { canonical: "/privacy" },
};

const sections = [
  {
    h: "What this website collects",
    p: "This website does not use tracking cookies or analytics, and the contact form does not store your details on our server. When you press a send button, your message opens in WhatsApp or in your own email app, and nothing is sent until you choose to send it there.",
  },
  {
    h: "The AI assistant",
    p: "If you type a question into the AI assistant, your messages in that chat are sent to an AI service through Vercel's AI Gateway so an answer can be written. We do not save these chats. Please do not share passwords, payment details, or other sensitive information in the chat.",
  },
  {
    h: "Hosting",
    p: "This website is hosted by Vercel. Like most hosting services, Vercel may process basic technical data, such as your IP address, to deliver the site and keep it secure.",
  },
  {
    h: "What you share with us",
    p: "If you contact us by WhatsApp, email, or LinkedIn, we receive the details you include, such as your name, email address, phone number, and business information. We use them only to reply to you, prepare a quote, and deliver the work you ask for.",
  },
  {
    h: "Who we share it with",
    p: "We do not sell your information, and we do not share it with anyone outside your project. Messages you send travel through the service you choose (WhatsApp, your email provider, or LinkedIn), which have their own privacy policies.",
  },
  {
    h: "Client project data",
    p: "During a project, we access only the accounts and data the work requires, and we use your own accounts wherever possible.",
  },
];

export default function PrivacyPage() {
  return (
    <section className="pt-14 pb-24 md:pt-20">
      <div className="wrap max-w-[720px]">
        <h1 className="text-[clamp(2rem,6vw,2.8rem)]">Privacy Policy</h1>
        <p className="mt-2 text-mut">Last updated: November 14, 2026</p>
        {sections.map((s) => (
          <div key={s.h}>
            <h2 className="mt-9 text-[1.2rem]">{s.h}</h2>
            <p className="mt-2 text-mut">{s.p}</p>
          </div>
        ))}
        <h2 className="mt-9 text-[1.2rem]">Your choices</h2>
        <p className="mt-2 text-mut">
          You can ask us at any time to show, correct, or delete the information you have sent us. Write to{" "}
          <a className="font-medium text-gold-d underline" href={`mailto:${SITE.email}`}>{SITE.email}</a>.
        </p>
        <h2 className="mt-9 text-[1.2rem]">Contact</h2>
        <p className="mt-2 text-mut">{SITE.name}, {SITE.city}, {SITE.country}. Email: <a className="font-medium text-gold-d underline" href={`mailto:${SITE.email}`}>{SITE.email}</a></p>
      </div>
    </section>
  );
}
