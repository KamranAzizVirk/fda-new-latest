import type { Metadata } from "next";
import { ABOUT } from "@/lib/content";
import { Icon } from "@/components/Icon";
import { Reveal } from "@/components/Reveal";
import { Rise } from "@/components/Rise";
import { FounderPhoto } from "@/components/FounderPhoto";
import { CtaBand, Eyebrow } from "@/components/ui";

export const metadata: Metadata = {
  title: "About Me",
  description: "Kamran Aziz, Founder and CEO of FDE - AI Automation Agency in Faisalabad, Pakistan. The story behind FDE and how we work with small and medium businesses.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <>
      <section className="pt-14 pb-12 md:pt-20 md:pb-16">
        <div className="wrap grid items-center gap-10 md:grid-cols-[auto_1fr] md:gap-14">
          <Rise className="flex justify-center"><FounderPhoto size={200} priority /></Rise>
          <div>
            <Rise><Eyebrow>{ABOUT.label}</Eyebrow></Rise>
            <Rise delay={0.05}><h1 className="text-[clamp(2.2rem,7vw,3.6rem)]">{ABOUT.heading}</h1></Rise>
            <Rise delay={0.1}><p className="mt-3 text-lg text-mut">{ABOUT.sub}</p></Rise>
          </div>
        </div>
      </section>

      <section className="pb-16 md:pb-24">
        <div className="wrap grid gap-6 lg:grid-cols-[1.25fr_.75fr]">
          <Reveal className="rounded-[22px] border border-line bg-card p-6 md:p-10">
            <h2 className="text-[clamp(1.6rem,4vw,2.2rem)]">{ABOUT.story.heading}</h2>
            {ABOUT.story.paragraphs.map((p, i) => <p key={i} className="mt-5 text-[1.04rem] leading-[1.75]">{p}</p>)}
          </Reveal>
          <Reveal delay={0.08} className="flex flex-col justify-center rounded-[22px] bg-ink p-6 text-[#F6F1E6] md:p-9">
            <Eyebrow dark>{ABOUT.fde.heading}</Eyebrow>
            <p className="text-[1.35rem] font-semibold leading-snug">{ABOUT.fde.lead}</p>
            <p className="mt-4 text-[#C9C2B3]">{ABOUT.fde.text}</p>
          </Reveal>
        </div>
      </section>

      <section className="bg-bg2 py-16 md:py-24">
        <div className="wrap">
          <Reveal className="max-w-2xl"><h2 className="text-[clamp(1.8rem,4.8vw,2.65rem)]">{ABOUT.beliefs.heading}</h2></Reveal>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {ABOUT.beliefs.items.map((b, i) => (
              <Reveal key={b.title} delay={i * 0.07} className="rounded-[18px] border border-line bg-card p-6">
                <span className="mb-4 grid h-11 w-11 place-items-center rounded-xl bg-gold-l text-gold-d"><Icon name={b.icon} animate /></span>
                <h3 className="font-semibold">{b.title}</h3>
                <p className="mt-1.5 text-[.95rem] text-mut">{b.text}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="wrap grid gap-5 md:grid-cols-2">
          {[ABOUT.who, ABOUT.how].map((b, i) => (
            <Reveal key={b.heading} delay={i * 0.08} className="rounded-[20px] border border-line bg-card p-6 md:p-8">
              <span className="mb-4 grid h-11 w-11 place-items-center rounded-xl bg-gold-l text-gold-d"><Icon name={i ? "globe" : "target"} animate /></span>
              <h2 className="text-[1.4rem]">{b.heading}</h2>
              <p className="mt-3 text-mut">{b.text}</p>
            </Reveal>
          ))}
        </div>
      </section>

      <CtaBand heading={ABOUT.closing} secondary="linkedin" />
    </>
  );
}
