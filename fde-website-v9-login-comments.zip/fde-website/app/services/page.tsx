import type { Metadata } from "next";
import { CORE_SERVICES, SERVICES, SERVICES_PAGE } from "@/lib/content";
import { Icon } from "@/components/Icon";
import { Reveal } from "@/components/Reveal";
import { Rise } from "@/components/Rise";
import { LottiePlayer } from "@/components/LottiePlayer";
import { ToolsStrip } from "@/components/ToolsStrip";
import { TeamSection } from "@/components/TeamSection";
import { CoreServices } from "@/components/CoreServices";
import { CtaBand, Eyebrow } from "@/components/ui";

export const metadata: Metadata = {
  title: "Services",
  description: "AI voice and chat agents, n8n and WhatsApp automation, lead generation, CRM and email, Google Workspace automation, web design, and website and app development.",
  alternates: { canonical: "/services" },
};

export default function ServicesPage() {
  return (
    <>
      <section className="pt-14 pb-10 md:pt-20 md:pb-14">
        <div className="wrap grid items-center gap-10 lg:grid-cols-[1.1fr_.9fr]">
          <div>
            <Rise><Eyebrow>{SERVICES_PAGE.label}</Eyebrow></Rise>
            <Rise delay={0.05}><h1 className="text-[clamp(2.2rem,7vw,3.6rem)]">{SERVICES_PAGE.heading}</h1></Rise>
            <Rise delay={0.1}><p className="mt-5 max-w-[56ch] text-lg text-mut">{SERVICES_PAGE.intro}</p></Rise>
          </div>
          <Rise delay={0.1} className="flex justify-center">
            <LottiePlayer src="/lottie/ai-chat.json" label="Animation: a customer asks a question and the AI assistant replies" className="aspect-[4/3] w-full max-w-[420px]" />
          </Rise>
        </div>
      </section>

      {/* The 4 main services (improve3) */}
      <CoreServices />

      {/* The six detailed cards below are unchanged; only this small heading was added above them. */}
      <section className="pb-16 md:pb-24">
        <Reveal className="wrap mb-8 max-w-none">
          <h2 className="text-[clamp(1.5rem,4vw,2.1rem)]">{CORE_SERVICES.moreHeading}</h2>
          <p className="mt-2 text-mut">{CORE_SERVICES.moreText}</p>
        </Reveal>
        <div className="wrap grid gap-5 md:grid-cols-2">
          {SERVICES.map((s, i) => (
            <Reveal key={s.title} delay={(i % 2) * 0.08} className="card-lift group flex flex-col rounded-[22px] border border-line bg-card p-6 md:p-8">
              <div className="mb-5 flex items-center gap-4">
                <span className="grid h-12 w-12 flex-none place-items-center rounded-[14px] bg-gold-l text-gold-d"><Icon name={s.icon} className="h-6 w-6" animate /></span>
                <span className="text-[.78rem] font-semibold tracking-[.12em] text-gold-d">0{i + 1}</span>
              </div>
              <h2 className="text-[1.35rem] !leading-snug">{s.title}</h2>
              <p className="mt-2 text-mut">{s.tagline}</p>
              <ul className="mt-5 grid gap-2.5 text-[.95rem]">
                {s.points.map((p) => (
                  <li key={p} className="flex gap-2.5"><Icon name="check" className="mt-1 h-4 w-4 flex-none text-gold-d" />{p}</li>
                ))}
              </ul>
              <p className="mt-auto border-t border-line pt-4 text-[.9rem] text-mut [margin-top:1.5rem]">
                <strong className="font-semibold text-ink">Good for:</strong> {s.goodFor}
              </p>
            </Reveal>
          ))}
        </div>
      </section>

      <TeamSection />

      <section className="bg-bg2 py-14 md:py-20">
        <div className="wrap">
          <Reveal><h2 className="text-center text-[clamp(1.6rem,4.2vw,2.3rem)]">{SERVICES_PAGE.includesHeading}</h2></Reveal>
          <ul className="mx-auto mt-9 grid max-w-5xl gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {SERVICES_PAGE.includes.map((t, i) => (
              <li key={t}>
                <Reveal delay={i * 0.06} className="flex h-full items-center gap-3 rounded-[14px] border border-line bg-card px-4 py-4 text-[.95rem] font-medium">
                  <Icon name="check" className="h-5 w-5 flex-none text-gold-d" />{t}
                </Reveal>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <ToolsStrip />

      <CtaBand heading={SERVICES_PAGE.closing.heading} text={SERVICES_PAGE.closing.text} secondary="none" buttonLabel="Book a Call for a Custom Quote" />
    </>
  );
}
