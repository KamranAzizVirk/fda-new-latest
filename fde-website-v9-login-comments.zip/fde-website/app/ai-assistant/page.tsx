import type { Metadata } from "next";
import { FullChat } from "@/components/FullChat";

export const metadata: Metadata = {
  title: "FDE AI Assistant",
  description: "Chat with the FDE AI Assistant about automating your business.",
  robots: { index: false, follow: false },
};

export default function AiAssistantPage() {
  return <FullChat />;
}
