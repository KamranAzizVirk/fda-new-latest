import { streamText } from "ai";
import { buildSystemPrompt } from "@/lib/assistant";
import { checkRateLimit, clientKey } from "@/lib/rateLimit";

export const maxDuration = 30;

type ChatMessage = { role: "user" | "assistant"; content: string };

const MAX_MESSAGES = 12;
const MAX_CHARS = 1200;
const MAX_BODY_BYTES = 24_000;

const text = (msg: string, status: number, headers: Record<string, string> = {}) =>
  new Response(msg, { status, headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store", ...headers } });

/** Only this website's own pages may use the chat (blocks other sites from using it). */
function sameSite(req: Request): boolean {
  const site = req.headers.get("sec-fetch-site");
  if (site && site !== "same-origin") return false;
  const origin = req.headers.get("origin");
  if (!origin) return !!site; // very old browsers send neither; tools like curl are refused
  try {
    const host = req.headers.get("x-forwarded-host") || req.headers.get("host");
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

export async function POST(req: Request) {
  if (!sameSite(req)) return text("Forbidden", 403);
  if (!(req.headers.get("content-type") || "").toLowerCase().startsWith("application/json")) {
    return text("Invalid request", 415);
  }

  // Refuse oversized requests before reading them fully.
  const declared = Number(req.headers.get("content-length") || 0);
  if (declared > MAX_BODY_BYTES) return text("Request too large", 413);

  let body: unknown;
  try {
    const rawText = await req.text();
    if (rawText.length > MAX_BODY_BYTES) return text("Request too large", 413);
    body = JSON.parse(rawText);
  } catch {
    return text("Invalid request", 400);
  }

  const raw = (body as { messages?: unknown })?.messages;
  if (!Array.isArray(raw) || raw.length === 0 || raw.length > 60) {
    return text("Invalid request", 400);
  }

  // Keep only clean user/assistant text, the last few turns, with a length cap.
  const messages: ChatMessage[] = raw
    .filter((m): m is ChatMessage =>
      !!m && typeof m === "object" &&
      ((m as ChatMessage).role === "user" || (m as ChatMessage).role === "assistant") &&
      typeof (m as ChatMessage).content === "string")
    .slice(-MAX_MESSAGES)
    .map((m) => ({ role: m.role, content: m.content.slice(0, MAX_CHARS) }));

  if (messages.length === 0 || messages[messages.length - 1].role !== "user" || !messages[messages.length - 1].content.trim()) {
    return text("Invalid request", 400);
  }

  // Which chat window is asking: only the exact word "home" switches to the Home Page style.
  const agent = (body as { agent?: unknown })?.agent === "home" ? "home" : "site";

  // Message limit per visitor (protects the AI credits from spam and bots).
  const wait = checkRateLimit(clientKey(req));
  if (wait > 0) return text("Too many messages. Please try again later.", 429, { "Retry-After": String(wait) });

  try {
    const result = streamText({
      // Uses the Vercel AI Gateway. Change the model with the AI_MODEL environment variable.
      model: process.env.AI_MODEL || "openai/gpt-4o-mini",
      system: buildSystemPrompt(agent),
      messages,
      temperature: 0.3,
      maxOutputTokens: 400,
    });
    return result.toTextStreamResponse({ headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
  } catch {
    return text("Assistant unavailable", 503);
  }
}
