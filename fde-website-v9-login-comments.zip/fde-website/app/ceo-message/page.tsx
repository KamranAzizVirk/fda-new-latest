import type { Metadata } from "next";
import { CEO } from "@/lib/content";
import { SITE } from "@/lib/site";
import { Icon } from "@/components/Icon";
import { Reveal } from "@/components/Reveal";
import { Rise } from "@/components/Rise";
import { FounderPhoto } from "@/components/FounderPhoto";
import { BookCallButton, Eyebrow, LinkedInButton } from "@/components/ui";

export const metadata: Metadata = {
  title: "CEO Message",
  description: "A message from Kamran Aziz, Founder and CEO of FDE - AI Automation Agency: trust, quality, on-time delivery, and a USA standard of work.",
  alternates: { canonical: "/ceo-message" },
};

export default function CeoMessagePage() {
  return (
    <section className="pt-14 pb-20 md:pt-20 md:pb-28">
      <div className="wrap max-w-3xl">
        <Rise className="text-center">
          <div className="mb-6 flex justify-center"><FounderPhoto size={148} priority /></div>
          <Eyebrow>{CEO.label}</Eyebrow>
          <h1 className="mx-auto max-w-2xl text-[clamp(2.1rem,6.5vw,3.3rem)]">{CEO.heading}</h1>
        </Rise>

        <article className="mt-12 rounded-[24px] border border-line bg-card p-6 text-[1.06rem] leading-[1.75] md:p-11">
          {CEO.intro.map((p, i) => (
            <Rise key={i} delay={0.03 * i}><p className={i ? "mt-5" : ""}>{p}</p></Rise>
          ))}

          <div className="mt-7 grid gap-4">
            {CEO.promises.map((p, i) => (
              <Reveal key={p.title} delay={i * 0.06} className="flex gap-4 rounded-[16px] border border-line bg-bg p-5">
                <span className="grid h-11 w-11 flex-none place-items-center rounded-xl bg-gold-l text-gold-d"><Icon name={p.icon} animate /></span>
                <p className="text-[1rem] leading-relaxed"><strong className="font-semibold">{p.title}</strong> {p.text}</p>
              </Reveal>
            ))}
          </div>

          {CEO.outro.map((p, i) => (
            <Reveal key={i}><p className="mt-6">{p}</p></Reveal>
          ))}

          <Reveal className="mt-9 border-t border-line pt-7">
            <p>{CEO.signoff}</p>
            <p className="mt-3 text-[1.15rem] font-semibold">{SITE.founder}</p>
            <p className="text-[.95rem] text-mut">{SITE.founderTitle}</p>
            <p className="text-[.95rem] text-mut">{SITE.city}, {SITE.country}</p>
          </Reveal>
        </article>

        <Reveal className="mt-9 flex flex-wrap justify-center gap-3">
          <BookCallButton />
          <LinkedInButton />
        </Reveal>
      </div>
    </section>
  );
}
