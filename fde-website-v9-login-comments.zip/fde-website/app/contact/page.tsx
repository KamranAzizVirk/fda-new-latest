import type { Metadata } from "next";
import { CONTACT, FAQ } from "@/lib/content";
import { BOOK_CALL_URL, HELLO_URL, SITE } from "@/lib/site";
import { BrandIcon, Icon } from "@/components/Icon";
import { Reveal } from "@/components/Reveal";
import { ContactForm } from "@/components/ContactForm";
import { LottiePlayer } from "@/components/LottiePlayer";
import { CtaBand, PageHero } from "@/components/ui";
import { TrustBadges } from "@/components/TrustBadges";

export const metadata: Metadata = {
  title: "Contact",
  description: "Contact FDE - AI Automation Agency on WhatsApp, email, or LinkedIn. Book a free call and get a custom quote for your business.",
  alternates: { canonical: "/contact" },
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: FAQ.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
};

export default function ContactPage() {
  const channels = [
    { label: "Book a call", value: "Book a free call on WhatsApp", href: BOOK_CALL_URL, icon: <Icon name="calendar" className="h-[18px] w-[18px]" /> },
    { label: "WhatsApp", value: SITE.phoneDisplay, href: HELLO_URL, icon: <BrandIcon name="whatsapp" className="h-[18px] w-[18px]" /> },
    { label: "Email", value: <>{SITE.email.split("@")[0]}@<wbr />{SITE.email.split("@")[1]}</>, href: `mailto:${SITE.email}`, icon: <Icon name="mail" className="h-[18px] w-[18px]" /> },
    { label: "LinkedIn", value: SITE.founder, href: SITE.linkedin, icon: <BrandIcon name="linkedin" className="h-[17px] w-[17px]" /> },
  ];

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd).replace(/</g, "\\u003c") }} />
      <PageHero label={CONTACT.label} heading={CONTACT.heading} intro={CONTACT.intro} />
      <div className="wrap pb-10 md:pb-12"><TrustBadges /></div>

      <section className="pb-16 md:pb-24">
        <div className="wrap grid gap-6 lg:grid-cols-[1.1fr_.9fr]">
          <Reveal className="min-w-0">
            <h2 className="mb-4 text-[1.4rem]">{CONTACT.formHeading}</h2>
            <ContactForm />
          </Reveal>

          <Reveal delay={0.08} className="flex min-w-0 flex-col rounded-[22px] bg-ink p-6 text-[#F6F1E6] md:p-8">
            <h2 className="text-[1.4rem]">{CONTACT.otherHeading}</h2>
            <ul className="mt-6 grid gap-3">
              {channels.map((c) => (
                <li key={c.label}>
                  <a href={c.href} target={c.href.startsWith("mailto:") ? undefined : "_blank"} rel="noopener noreferrer" className="group flex items-center gap-3.5">
                    <span className="grid h-11 w-11 flex-none place-items-center rounded-xl bg-[#2E2B27] text-gold-on-dark">{c.icon}</span>
                    <span className="min-w-0 leading-tight">
                      <span className="block text-[.74rem] font-semibold uppercase tracking-[.1em] text-[#A8A091]">{c.label}</span>
                      <span className="[overflow-wrap:anywhere] group-hover:underline">{c.value}</span>
                    </span>
                  </a>
                </li>
              ))}
              <li className="flex items-center gap-3.5">
                <span className="grid h-11 w-11 flex-none place-items-center rounded-xl bg-[#2E2B27] text-gold-on-dark"><Icon name="pin" className="h-[18px] w-[18px]" /></span>
                <span className="leading-tight">
                  <span className="block text-[.74rem] font-semibold uppercase tracking-[.1em] text-[#A8A091]">Location</span>
                  <span>{CONTACT.location}</span>
                </span>
              </li>
            </ul>
            <p className="mt-6 text-[.9rem] text-[#C9C2B3]">{CONTACT.videoNote}</p>
            <LottiePlayer src="/lottie/ai-agent.json" label="Animation: the FDE AI assistant, ready to help" className="mx-auto mt-auto aspect-[4/3] w-full max-w-[260px] pt-4" />
          </Reveal>
        </div>
      </section>

      <section className="faq bg-bg2 py-16 md:py-24">
        <div className="wrap max-w-[820px]">
          <Reveal><h2 className="mb-8 text-[clamp(1.8rem,4.8vw,2.65rem)]">{CONTACT.faqHeading}</h2></Reveal>
          {FAQ.map((f, i) => (
            <Reveal key={f.q} delay={Math.min(i, 4) * 0.04}>
              <details className="mt-2.5 rounded-2xl border border-line bg-card">
                <summary className="relative cursor-pointer py-5 pl-5 pr-14 text-[1.02rem] font-semibold">{f.q}</summary>
                <p className="max-w-[70ch] px-5 pb-5 text-mut">{f.a}</p>
              </details>
            </Reveal>
          ))}
        </div>
      </section>

      <CtaBand heading={CONTACT.closing} />
    </>
  );
}
