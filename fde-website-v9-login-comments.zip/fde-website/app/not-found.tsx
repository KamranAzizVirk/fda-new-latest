import Link from "next/link";

export default function NotFound() {
  return (
    <section className="py-28 text-center">
      <div className="wrap max-w-xl">
        <p className="eyebrow">404</p>
        <h1 className="text-[clamp(2rem,6vw,3rem)]">This page could not be found.</h1>
        <p className="mt-4 text-mut">The link may be old or mistyped.</p>
        <Link href="/" className="btn btn-gold mt-8">Back to home</Link>
      </div>
    </section>
  );
}
