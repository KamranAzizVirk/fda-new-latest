import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { FloatingActions } from "@/components/FloatingActions";
import { ChatLoader } from "@/components/ChatLoader";
import { MotionProvider } from "@/components/Reveal";
import { SITE } from "@/lib/site";

// Inter (variable, latin) is self-hosted: no request to Google, faster first paint.
const inter = localFont({ src: "./fonts/InterVariable-latin.woff2", weight: "100 900", display: "swap", variable: "--font-inter" });

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: { default: SITE.title, template: "%s | FDE - AI Automation Agency" },
  description: SITE.description,
  applicationName: SITE.name,
  authors: [{ name: SITE.founder }],
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    siteName: SITE.name,
    url: SITE.url,
    title: "FDE - AI Automation Agency | I Build AI Agents That Work 24/7 For Your Business",
    description: "AI agents and automation that work for your business 24/7. Built around your business, with support after launch.",
    images: [{ url: "/og-image.jpg", width: 1200, height: 630, alt: "FDE - AI Automation Agency" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "FDE - AI Automation Agency | I Build AI Agents That Work 24/7 For Your Business",
    description: "AI agents and automation for small and medium businesses.",
    images: ["/og-image.jpg"],
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#FBF8F2",
  width: "device-width",
  initialScale: 1,
};

const orgJsonLd = {
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  "@id": `${SITE.url}/#org`,
  name: SITE.name,
  url: SITE.url,
  image: `${SITE.url}/og-image.jpg`,
  email: SITE.email,
  telephone: SITE.phoneIntl,
  description: SITE.description,
  address: { "@type": "PostalAddress", addressLocality: SITE.city, addressCountry: "PK" },
  areaServed: ["US", "GB", "EU", "Worldwide"],
  founder: { "@type": "Person", name: SITE.founder, jobTitle: SITE.founderTitle, sameAs: SITE.linkedin },
  sameAs: [SITE.linkedin],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={inter.variable}>
      <body>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(orgJsonLd).replace(/</g, "\\u003c") }} />
        <MotionProvider>
          <Header />
          <main id="main">{children}</main>
          <Footer />
          <FloatingActions />
          <ChatLoader />
        </MotionProvider>
      </body>
    </html>
  );
}
