// Server component: no JavaScript is sent for this.
/**
 * Same rise-in look for the top of each page, but pure CSS: it shows at once,
 * without waiting for JavaScript, so the first view appears fast on phones.
 */
export function Rise({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  return (
    <div className={`rise ${className}`} style={delay ? ({ "--d": `${delay}s` } as React.CSSProperties) : undefined}>
      {children}
    </div>
  );
}
