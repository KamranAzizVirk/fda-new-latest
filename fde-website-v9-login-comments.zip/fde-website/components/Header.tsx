"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { NAV, SITE } from "@/lib/site";
import { BookCallButton } from "./ui";
import { AuthButton, AuthRoot, MobileAuthRow } from "./AuthButton";

export function Logo() {
  return (
    <span className="flex items-center gap-2.5 whitespace-nowrap font-semibold tracking-[.02em]">
      <b aria-hidden="true" className="grid h-[38px] w-[38px] place-items-center rounded-[10px] bg-ink text-[.7rem] font-bold tracking-[.04em] text-gold-on-dark">FDE</b>
      <span className="text-[.95rem] max-[359px]:text-[.84rem]">{SITE.headerName}</span>
    </span>
  );
}

export function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  useEffect(() => setOpen(false), [pathname]);

  // For menu links that point to a section (like "/#team"): after the jump, check once or twice
  // that the section really sits at the top, even if parts of the page finished loading on the way.
  const alignSection = (href: string) => {
    const id = href.split("#")[1];
    if (!id) return;
    [700, 1600].forEach((ms) =>
      window.setTimeout(() => {
        const el = document.getElementById(id);
        if (el && Math.abs(el.getBoundingClientRect().top - 76) > 12) el.scrollIntoView();
      }, ms)
    );
  };

  // Clicking the link of the page you are already on (e.g. "Home" while on Home) should go back to the very top.
  // Next.js does not move the page in that case, so we do it here. Other pages already open at the top.
  const toTopIfSamePage = (href: string) => {
    if (href.includes("#") || href !== pathname) return;
    if (window.location.hash) window.history.replaceState(null, "", href);
    window.scrollTo({ top: 0 });
  };

  const isActive = (href: string) => (href === "/" ? pathname === "/" : pathname.startsWith(href));

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-bg/90 backdrop-blur-md">
      <a href="#main" className="absolute -left-[999px] rounded-lg bg-white px-3 py-2 focus:left-3 focus:top-3 focus:z-50">Skip to content</a>
      <div className="wrap flex h-16 items-center justify-between gap-4 lg:gap-3 xl:gap-4">
        <Link href="/" onClick={() => toTopIfSamePage("/")}><Logo /></Link>

        <nav aria-label="Main" className="hidden items-center gap-3 whitespace-nowrap text-[.88rem] lg:flex xl:gap-7 xl:text-[.92rem]">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              aria-current={isActive(item.href) ? "page" : undefined}
              onClick={() => { toTopIfSamePage(item.href); alignSection(item.href); }}
              className={`relative py-1 transition-colors hover:text-ink ${isActive(item.href) ? "font-semibold text-ink after:absolute after:inset-x-0 after:-bottom-0.5 after:h-0.5 after:rounded after:bg-gold" : "text-mut"}`}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <AuthButton />
          <BookCallButton className="btn btn-ink !min-h-10 !px-[18px] !text-[.88rem] max-[479px]:hidden lg:!min-h-9 lg:!px-3.5 lg:!text-[.82rem]" />
          <button
            type="button"
            className="grid h-[42px] w-[42px] place-items-center rounded-[10px] border border-line bg-card lg:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            aria-controls="mobile-nav"
            onClick={() => setOpen((v) => !v)}
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" aria-hidden="true">
              {open ? <path d="M6 6l12 12M18 6 6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
            </svg>
          </button>
        </div>
      </div>

      {open && (
        <nav id="mobile-nav" aria-label="Mobile" className="max-h-[calc(100dvh-4rem)] overflow-y-auto overscroll-contain border-t border-line pb-24 pt-2 lg:hidden">
          <div className="pt-2"><MobileAuthRow onDone={() => setOpen(false)} /></div>
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              aria-current={isActive(item.href) ? "page" : undefined}
              onClick={() => { setOpen(false); toTopIfSamePage(item.href); alignSection(item.href); }}
              className={`block px-5 py-3.5 font-medium ${isActive(item.href) ? "text-gold-d" : ""}`}
            >
              {item.label}
            </Link>
          ))}
          <div className="px-5 pt-2">
            <BookCallButton className="btn btn-gold w-full" />
          </div>
        </nav>
      )}
      <AuthRoot />
    </header>
  );
}
