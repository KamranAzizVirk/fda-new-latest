"use client";

import { HELLO_URL } from "@/lib/site";
import { BrandIcon } from "./Icon";
import { BookCallButton } from "./ui";
import { CursorGlow } from "./CursorGlow";

export const OPEN_CHAT_EVENT = "fde:open-chat";

export function openChat() {
  window.dispatchEvent(new Event(OPEN_CHAT_EVENT));
}

/** Phones: bottom bar (unchanged). Desktop: two small round icon buttons, no text (robot = AI chat page in a new tab, green = WhatsApp). */
export function FloatingActions() {
  return (
    <>
      <CursorGlow />
      <div className="fixed inset-x-0 bottom-0 z-50 flex gap-2.5 border-t border-line bg-bg/95 px-3.5 pt-2.5 pb-[calc(10px+env(safe-area-inset-bottom))] backdrop-blur-md lg:hidden">
        <BookCallButton className="btn btn-gold !min-h-12 flex-1" />
        <button type="button" onClick={openChat} aria-label="Ask our AI assistant" className="grid h-12 w-12 flex-none place-items-center rounded-full bg-ink text-gold-on-dark">
          <BotGlyph className="h-6 w-6" />
        </button>
        <a href={HELLO_URL} target="_blank" rel="noopener noreferrer" aria-label="Chat with us on WhatsApp" className="grid h-12 w-12 flex-none place-items-center rounded-full bg-wa-bright text-[#06301A]">
          <BrandIcon name="whatsapp" className="h-6 w-6" />
        </a>
      </div>

      <div className="fixed bottom-5 right-5 z-50 hidden flex-col items-center gap-2.5 lg:flex">
        <a
          href="/ai-assistant"
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Chat with FDE AI Assistant"
          data-tip="FDE AI Assistant"
          className="after:pointer-events-none after:absolute after:right-full after:top-1/2 after:mr-3 after:-translate-y-1/2 after:whitespace-nowrap after:rounded-md after:bg-ink after:px-2.5 after:py-1 after:text-xs after:font-medium after:text-white after:opacity-0 after:transition-opacity after:content-[attr(data-tip)] hover:after:opacity-100 focus-visible:after:opacity-100 relative grid h-14 w-14 place-items-center rounded-full bg-black shadow-[0_0_0_2px_rgba(56,189,248,.35),0_0_20px_5px_rgba(56,189,248,.4)] transition-transform hover:-translate-y-0.5"
        >
          <span className="block h-full w-full overflow-hidden rounded-full">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/lottie/robot-icon.webp" width={56} height={56} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover" />
          </span>
        </a>
        <a
          href={HELLO_URL}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Chat with us on WhatsApp"
          data-tip="WhatsApp"
          className="after:pointer-events-none after:absolute after:right-full after:top-1/2 after:mr-3 after:-translate-y-1/2 after:whitespace-nowrap after:rounded-md after:bg-ink after:px-2.5 after:py-1 after:text-xs after:font-medium after:text-white after:opacity-0 after:transition-opacity after:content-[attr(data-tip)] hover:after:opacity-100 focus-visible:after:opacity-100 relative grid h-14 w-14 place-items-center rounded-full bg-wa-bright text-[#06301A] shadow-[0_14px_30px_-10px_rgba(18,140,74,.7)] transition-transform hover:-translate-y-0.5"
        >
          <BrandIcon name="whatsapp" className="h-7 w-7" />
        </a>
      </div>
    </>
  );
}

export function BotGlyph({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      <rect x="4.5" y="8" width="15" height="11" rx="3.5" />
      <path d="M12 8V4.6M2.5 12.5v3M21.5 12.5v3M9.5 16h5" />
      <circle cx="12" cy="3.8" r="1" fill="currentColor" />
      <circle cx="9" cy="12.3" r="1.1" fill="currentColor" stroke="none" className="bot-eye" />
      <circle cx="15" cy="12.3" r="1.1" fill="currentColor" stroke="none" className="bot-eye" />
    </svg>
  );
}
