"use client";

import { useState } from "react";
import { EXAMPLE_TAGS, PROJECT_FILTERS, PROJECTS, type ProjectTag } from "@/lib/content";
import { Icon } from "./Icon";
import { Reveal } from "./Reveal";
import { LottiePlayer } from "./LottiePlayer";
import { Eyebrow } from "./ui";

type FilterId = "all" | ProjectTag;

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <dt className="text-[.74rem] font-semibold uppercase tracking-[.12em] text-gold-d">{label}</dt>
      <dd className="mt-1 text-[.96rem]">{children}</dd>
    </div>
  );
}

/** Projects page body: filter buttons + live project + example solutions. All cards are in the HTML for Google. */
export function ProjectsBrowser() {
  const [filter, setFilter] = useState<FilterId>("all");
  const live = PROJECTS.live;

  const showLive = filter === "all" || filter === "live";
  const visibleExamples = PROJECTS.examples.map((_, i) => filter === "all" || EXAMPLE_TAGS[i].includes(filter as ProjectTag));
  const exampleCount = visibleExamples.filter(Boolean).length;
  const total = (showLive ? 1 : 0) + exampleCount;

  return (
    <>
      {/* Filter buttons */}
      <div className="wrap pb-8 md:pb-10">
        <div role="group" aria-label="Filter projects" className="pf-bar -mx-5 flex gap-2 overflow-x-auto px-5 pb-1 sm:mx-0 sm:flex-wrap sm:px-0">
          {PROJECT_FILTERS.map((f) => {
            const on = filter === f.id;
            return (
              <button
                key={f.id}
                type="button"
                aria-pressed={on}
                onClick={() => setFilter(f.id)}
                className={`min-h-11 flex-none whitespace-nowrap rounded-full border px-4 text-[.9rem] font-semibold transition-colors ${
                  on ? "border-ink bg-ink text-bg" : "border-line bg-card text-ink hover:border-gold"
                }`}
              >
                {f.label}
              </button>
            );
          })}
        </div>
        <p className="mt-3 text-[.85rem] text-mut" aria-live="polite">
          Showing {total} {total === 1 ? "project" : "projects"}
        </p>
      </div>

      {/* Live project */}
      <section hidden={!showLive} className="pb-16 md:pb-24">
        <div className="wrap">
          <Reveal className="grid overflow-hidden rounded-[26px] bg-ink text-[#F6F1E6] lg:grid-cols-[1.2fr_.8fr]">
            <div className="px-6 py-9 md:px-10 md:py-11">
              <Eyebrow dark>Demo project</Eyebrow>{/* Original: "Live project" */}
              <h2 className="text-[clamp(1.6rem,4.4vw,2.4rem)]">{live.title}</h2>
              <dl className="mt-6 grid gap-5 [&_dd]:text-[#D9D2C3] [&_dt]:!text-gold-on-dark">
                <Row label="Problem">{live.problem}</Row>
                <Row label="Our solution">{live.solution}</Row>
                <Row label="What it does">{live.result}</Row>
              </dl>
              {live.showDemoButton && (
                <a href={live.url} target="_blank" rel="noopener noreferrer" className="btn mt-8 bg-gold-on-dark text-ink hover:bg-[#E8C676]">
                  Open live demo <span aria-hidden="true">&rarr;</span>
                </a>
              )}
              <p className="mt-4 text-[.82rem] text-[#A8A091]">{live.note}</p>
            </div>
            <div className="flex items-center justify-center bg-[#242220] p-6">
              <LottiePlayer src="/lottie/workflow.json" label="Animation: a workflow moving from step to step until the job is done" className="aspect-[4/3] w-full max-w-[380px]" />
            </div>
          </Reveal>
        </div>
      </section>

      {/* Example solutions */}
      <section hidden={exampleCount === 0} className="bg-bg2 py-16 md:py-24">
        <div className="wrap">
          <Reveal className="max-w-2xl">
            <Eyebrow>{PROJECTS.examplesSub}</Eyebrow>
            <h2 className="text-[clamp(1.8rem,4.8vw,2.65rem)]">{PROJECTS.examplesHeading}</h2>
          </Reveal>
          <div className="mt-10 grid gap-5 md:grid-cols-2">
            {PROJECTS.examples.map((e, i) => (
              <div key={e.title} hidden={!visibleExamples[i]}>
                <Reveal className="card-lift group flex h-full flex-col rounded-[20px] border border-line bg-card p-6 md:p-7">
                  <div className="mb-5 flex items-center justify-between gap-3">
                    <span className="grid h-[46px] w-[46px] place-items-center rounded-[13px] bg-gold-l text-gold-d"><Icon name={e.icon} className="h-[22px] w-[22px]" animate /></span>
                    <span className="rounded-full border border-line px-2.5 py-1 text-[.7rem] font-semibold uppercase tracking-[.08em] text-mut">Example solution</span>
                  </div>
                  <h3 className="text-[1.15rem] font-semibold">{e.title}</h3>
                  <dl className="mt-4 grid gap-4">
                    <Row label="Problem">{e.problem}</Row>
                    <Row label="Our solution">{e.solution}</Row>
                    <Row label="Built to">{e.builtTo}</Row>
                  </dl>
                </Reveal>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
