import { TRUST_BADGES } from "@/lib/content";
import { Icon } from "./Icon";

/**
 * Honest trust badges: only commitments Kamran approved.
 * Pure HTML + CSS (no JavaScript), so it costs nothing in speed.
 */
export function TrustBadges({ className = "" }: { className?: string }) {
  return (
    <ul aria-label="Our commitments to you" className={`grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-6 ${className}`}>
      {TRUST_BADGES.map((b) => (
        <li
          key={b.text}
          className="group flex items-center gap-2.5 rounded-[14px] border border-line bg-card px-3 py-3 text-[.84rem] font-medium leading-snug lg:flex-col lg:items-start lg:gap-2 lg:px-4 lg:py-4"
        >
          <span className="grid h-8 w-8 flex-none place-items-center rounded-[10px] bg-gold-l text-gold-d">
            <Icon name={b.icon} className="h-[17px] w-[17px]" animate />
          </span>
          {b.text}
        </li>
      ))}
    </ul>
  );
}
