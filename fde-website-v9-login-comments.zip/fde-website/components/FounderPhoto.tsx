import Image from "next/image";
import photo from "@/public/kamran-aziz.jpg";

/** Kamran's own photo, unchanged apart from the cream background he approved. */
export function FounderPhoto({ size = 168, priority = false }: { size?: number; priority?: boolean }) {
  return (
    // "person-ring": slow rotating pink ring, laptop/desktop only (see globals.css).
    <span className="person-ring">
    <Image
      src={photo}
      alt="Kamran Aziz, Founder of FDE - AI Automation Agency"
      width={size}
      height={size}
      preload={priority}
      fetchPriority={priority ? "high" : undefined}
      loading={priority ? "eager" : "lazy"}
      placeholder="blur"
      sizes={`${size}px`}
      className="rounded-full border-[3px] border-card bg-bg2 object-cover shadow-[0_0_0_2px_var(--color-gold)]"
      style={{ objectPosition: "50% 18%" }}
    />
    </span>
  );
}
