"use client";

import dynamic from "next/dynamic";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { OPEN_CHAT_EVENT } from "./FloatingActions";

// The chat window's code is only downloaded the first time someone taps "Ask FDE AI".
const ChatAgent = dynamic(() => import("./ChatAgent").then((m) => m.ChatAgent), { ssr: false });
// The Home Page has its own, upgraded AI Agent. Other pages keep the original chat window.
const HomeChatAgent = dynamic(() => import("./HomeChatAgent").then((m) => m.HomeChatAgent), { ssr: false });

export function ChatLoader() {
  const pathname = usePathname();
  const isHome = pathname === "/";
  const here = isHome ? "home" : "site";
  const [wanted, setWanted] = useState<null | "home" | "site">(null);

  useEffect(() => {
    const onOpen = () => setWanted(window.location.pathname === "/" ? "home" : "site");
    window.addEventListener(OPEN_CHAT_EVENT, onOpen);
    return () => window.removeEventListener(OPEN_CHAT_EVENT, onOpen);
  }, []);

  // When the visitor moves between the Home Page and another page, close the chat
  // so each page shows its own chat window the next time it is opened.
  useEffect(() => {
    setWanted((w) => (w && w !== here ? null : w));
  }, [here]);

  if (!wanted || wanted !== here) return null;
  return wanted === "home" ? <HomeChatAgent initialOpen /> : <ChatAgent initialOpen />;
}
