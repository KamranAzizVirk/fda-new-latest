"use client";

import { useEffect, useRef, useState } from "react";

/**
 * Desktop only: a very soft blue glow that slowly follows the mouse.
 * Plain CSS + a few lines of code (no library, no image). On phones, tablets,
 * touch screens and "reduce motion" settings it is never created at all.
 */
export function CursorGlow() {
  const [on, setOn] = useState(false);
  const el = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const mq = window.matchMedia("(min-width: 1024px) and (hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference)");
    if (mq.matches) setOn(true);
  }, []);

  useEffect(() => {
    if (!on) return;
    let x = window.innerWidth / 2, y = window.innerHeight / 3, tx = x, ty = y, raf = 0;
    const tick = () => {
      x += (tx - x) * 0.1;
      y += (ty - y) * 0.1;
      if (el.current) el.current.style.transform = `translate3d(${x - 260}px, ${y - 260}px, 0)`;
      raf = Math.abs(tx - x) + Math.abs(ty - y) > 0.5 ? requestAnimationFrame(tick) : 0;
    };
    const move = (e: PointerEvent) => {
      if (e.pointerType !== "mouse") return;
      tx = e.clientX;
      ty = e.clientY;
      if (el.current) el.current.style.opacity = "1";
      if (!raf) raf = requestAnimationFrame(tick);
    };
    const leave = () => {
      if (el.current) el.current.style.opacity = "0";
    };
    window.addEventListener("pointermove", move, { passive: true });
    document.documentElement.addEventListener("mouseleave", leave);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("pointermove", move);
      document.documentElement.removeEventListener("mouseleave", leave);
    };
  }, [on]);

  if (!on) return null;
  return <div ref={el} className="cursor-glow" aria-hidden="true" />;
}
