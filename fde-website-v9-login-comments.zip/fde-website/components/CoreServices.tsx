import { CORE_SERVICES } from "@/lib/content";
import { Icon } from "./Icon";
import { Reveal } from "./Reveal";
import { Eyebrow } from "./ui";

/**
 * Services page only: the 4 main services (improve3).
 * Pure HTML + CSS (no extra JavaScript). Icons are drawn here so the shared icon set stays untouched.
 */
type Id = "voice" | "chat" | "flow" | "fde";

function ServiceIcon({ id }: { id: Id }) {
  const common = {
    viewBox: "0 0 32 32",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.7,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true,
    className: "h-7 w-7",
  };
  switch (id) {
    case "voice": // phone handset with sound waves
      return (
        <svg {...common}>
          <path d="M11.2 5.5 8 6.4c-1.2.4-1.9 1.6-1.7 2.9 1.2 8.2 7.2 14.6 15.4 16.2 1.3.2 2.5-.5 2.9-1.7l.9-3.2-5.3-2.8-2.3 2.2c-2.6-1.3-4.7-3.5-6-6l2.2-2.3z" fill="currentColor" fillOpacity=".14" />
          <path d="M19 6.5c3.2.5 5.7 3 6.2 6.2M19.3 10.6c1.3.4 2.3 1.4 2.7 2.7" />
        </svg>
      );
    case "chat": // two chat bubbles with a spark
      return (
        <svg {...common}>
          <path d="M5 8.5A3.5 3.5 0 0 1 8.5 5h10A3.5 3.5 0 0 1 22 8.5v5A3.5 3.5 0 0 1 18.5 17H12l-4.5 3.5V17A3.5 3.5 0 0 1 5 13.5z" fill="currentColor" fillOpacity=".14" />
          <path d="M25 13.5a3 3 0 0 1 2 2.8v4a3 3 0 0 1-3 3v3L20 23.3h-4.5" />
          <path d="M13.5 8.3l.8 1.9 1.9.8-1.9.8-.8 1.9-.8-1.9-1.9-.8 1.9-.8z" fill="currentColor" stroke="none" />
        </svg>
      );
    case "flow": // connected steps
      return (
        <svg {...common}>
          <rect x="4" y="5" width="9" height="7" rx="2.2" fill="currentColor" fillOpacity=".14" />
          <rect x="19" y="12.5" width="9" height="7" rx="2.2" fill="currentColor" fillOpacity=".14" />
          <rect x="4" y="20" width="9" height="7" rx="2.2" fill="currentColor" fillOpacity=".14" />
          <path d="M13 8.5h4.5a3 3 0 0 1 3 3v1M13 23.5h4.5a3 3 0 0 0 3-3v-1" />
        </svg>
      );
    default: // fde: engineer working inside the business (building + gear)
      return (
        <svg {...common}>
          <path d="M5 26V9.5a1.5 1.5 0 0 1 1.5-1.5H15a1.5 1.5 0 0 1 1.5 1.5V26z" fill="currentColor" fillOpacity=".14" />
          <path d="M3.5 26h25M8.5 12.5h4.5M8.5 16.5h4.5M8.5 20.5h4.5" />
          <circle cx="22.5" cy="17" r="2.3" />
          <path d="M22.5 11.8v1.7M22.5 20.5v1.7M27.7 17H26M19 17h-1.7M26.2 13.3 25 14.5M20 19.5l-1.2 1.2M26.2 20.7 25 19.5M20 14.5l-1.2-1.2" />
        </svg>
      );
  }
}

const tile = "grid h-14 w-14 flex-none place-items-center rounded-[18px] bg-[linear-gradient(145deg,#2a2622,#151311)] text-[#E8C676] shadow-[inset_0_1px_0_rgba(255,255,255,.12),0_14px_26px_-14px_rgba(60,44,10,.7)]";

export function CoreServices() {
  const { eyebrow, heading, items, fde } = CORE_SERVICES;
  return (
    <section aria-labelledby="core-services" className="pb-14 md:pb-20">
      <div className="wrap">
        <Reveal className="max-w-2xl">
          <Eyebrow>{eyebrow}</Eyebrow>
          <h2 id="core-services" className="text-[clamp(1.7rem,4.6vw,2.5rem)]">{heading}</h2>
        </Reveal>

        <ul className="mt-9 grid gap-4 md:grid-cols-3 md:gap-5">
          {items.map((s, i) => (
            <li key={s.id} className="h-full">
              <Reveal
                delay={i * 0.08}
                className="card-lift relative flex h-full flex-col overflow-hidden rounded-[24px] border border-line bg-[linear-gradient(180deg,#fffdf9,#fbf6ea)] p-6 shadow-[0_24px_48px_-36px_rgba(60,44,10,.45)] md:p-7"
              >
                <span aria-hidden="true" className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-[radial-gradient(closest-side,rgba(184,137,43,.2),transparent)]" />
                <span className={tile}><ServiceIcon id={s.id} /></span>
                <h3 className="mt-6 text-[1.3rem] font-semibold !leading-snug tracking-[-.02em]">{s.title}</h3>
                <p className="mt-2.5 text-[1rem] leading-relaxed text-mut">{s.text}</p>
              </Reveal>
            </li>
          ))}
        </ul>

        <Reveal className="relative mt-4 overflow-hidden rounded-[26px] bg-ink p-6 text-[#F6F1E6] md:mt-5 md:p-9">
          <span aria-hidden="true" className="pointer-events-none absolute -right-16 -top-24 h-72 w-72 rounded-full bg-[radial-gradient(closest-side,rgba(232,198,118,.2),transparent)]" />
          <div className="relative grid gap-7 lg:grid-cols-[1.2fr_.8fr] lg:items-center lg:gap-12">
            <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:gap-6">
              <span className="grid h-14 w-14 flex-none place-items-center rounded-[18px] bg-[linear-gradient(145deg,#f0d38c,#b8892b)] text-ink shadow-[inset_0_1px_0_rgba(255,255,255,.4)]"><ServiceIcon id="fde" /></span>
              <div>
                <h3 className="text-[1.4rem] font-semibold !leading-snug tracking-[-.02em] md:text-[1.6rem]">{fde.title}</h3>
                <p className="mt-2.5 max-w-[58ch] leading-relaxed text-[#C9C2B3]">{fde.text}</p>
              </div>
            </div>
            <ul className="grid gap-2.5">
              {fde.points.map((p) => (
                <li key={p} className="flex items-center gap-3 rounded-[14px] border border-[#3a362f] bg-[#242220] px-4 py-3 text-[.95rem] font-medium">
                  <Icon name="check" className="h-[18px] w-[18px] flex-none text-[#E8C676]" />{p}
                </li>
              ))}
            </ul>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
