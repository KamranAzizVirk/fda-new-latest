import Link from "next/link";
import { BOOK_CALL_URL, HELLO_URL } from "@/lib/site";
import { BrandIcon, Icon } from "./Icon";
import { Reveal } from "./Reveal";
import { Rise } from "./Rise";

export function Eyebrow({ children, dark = false }: { children: React.ReactNode; dark?: boolean }) {
  return <span className={`eyebrow${dark ? " !text-gold-on-dark" : ""}`}>{children}</span>;
}

export function BookCallButton({ label = "Book a Call", className = "btn btn-gold" }: { label?: string; className?: string }) {
  return (
    <a className={className} href={BOOK_CALL_URL} target="_blank" rel="noopener noreferrer">
      <Icon name="calendar" className="h-[18px] w-[18px]" />
      {label}
    </a>
  );
}

export function WhatsAppButton({ label = "Chat on WhatsApp", className = "btn btn-wa" }: { label?: string; className?: string }) {
  return (
    <a className={className} href={HELLO_URL} target="_blank" rel="noopener noreferrer">
      <BrandIcon name="whatsapp" className="h-[19px] w-[19px]" />
      {label}
    </a>
  );
}

export function LinkedInButton({ className = "btn btn-outline" }: { className?: string }) {
  return (
    <a className={className} href="https://www.linkedin.com/in/kamran-aziz-69b9651a0" target="_blank" rel="noopener noreferrer">
      <BrandIcon name="linkedin" className="h-[17px] w-[17px] text-[#0A66C2]" />
      Connect on LinkedIn
    </a>
  );
}

/** Top block of every inner page. */
export function PageHero({ label, heading, intro, children }: { label: string; heading: string; intro?: string; children?: React.ReactNode }) {
  return (
    <section className="pt-14 pb-10 md:pt-20 md:pb-14">
      <div className="wrap max-w-3xl">
        <Rise><Eyebrow>{label}</Eyebrow></Rise>
        <Rise delay={0.05}><h1 className="text-[clamp(2.2rem,7vw,3.6rem)]">{heading}</h1></Rise>
        {intro && <Rise delay={0.1}><p className="mt-5 text-lg text-mut max-w-[60ch]">{intro}</p></Rise>}
        {children}
      </div>
    </section>
  );
}

/** Dark closing call-to-action band used at the bottom of pages. */
export function CtaBand({
  heading,
  text,
  secondary = "whatsapp",
  buttonLabel = "Book a Call",
}: {
  heading: string;
  text?: string;
  secondary?: "whatsapp" | "linkedin" | "none";
  buttonLabel?: string;
}) {
  return (
    <section className="py-16 md:py-24">
      <div className="wrap">
        <Reveal className="rounded-[28px] bg-ink px-6 py-12 text-center text-[#F6F1E6] md:px-16 md:py-16">
          <h2 className="mx-auto max-w-2xl text-[clamp(1.8rem,4.6vw,2.7rem)]">{heading}</h2>
          {text && <p className="mx-auto mt-4 max-w-xl text-[#C9C2B3]">{text}</p>}
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <BookCallButton label={buttonLabel} className="btn bg-gold-on-dark text-ink hover:bg-[#E8C676]" />
            {secondary === "whatsapp" && <WhatsAppButton />}
            {secondary === "linkedin" && <LinkedInButton className="btn border-[#5a544a] text-[#F6F1E6] hover:border-[#F6F1E6]" />}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export function TextLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link href={href} className="inline-flex items-center gap-1.5 font-semibold text-gold-d hover:text-ink">
      {children} <span aria-hidden="true">&rarr;</span>
    </Link>
  );
}
