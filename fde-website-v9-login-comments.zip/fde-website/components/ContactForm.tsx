"use client";

import { useRef, useState } from "react";
import { SITE, waLink } from "@/lib/site";
import { BrandIcon, Icon } from "./Icon";

const field =
  "w-full rounded-xl border border-line bg-white px-3.5 py-3 text-base text-ink placeholder:text-[#9b9488] focus:border-gold focus:outline-none focus:ring-[3px] focus:ring-gold/20";

/** No server needed: the message opens in WhatsApp or the visitor's email app, ready to send. */
export function ContactForm() {
  const via = useRef<"wa" | "email">("wa");
  const [error, setError] = useState("");

  function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const name = String(data.get("name") || "").trim();
    const contact = String(data.get("contact") || "").trim();
    const message = String(data.get("message") || "").trim();

    if (!name || !contact || message.length < 5) {
      setError("Please add your name, your email or phone, and a short message.");
      return;
    }
    setError("");

    const text = `Hi FDE - AI Automation Agency,\n\nName: ${name}\nEmail or phone: ${contact}\n\n${message}`;
    if (via.current === "email") {
      window.location.href = `mailto:${SITE.email}?subject=${encodeURIComponent(`Automation inquiry from ${name}`)}&body=${encodeURIComponent(text)}`;
    } else {
      // "noopener" in window.open() would make it return null, so we clear opener ourselves.
      const w = window.open(waLink(text), "_blank");
      if (w) w.opener = null;
      else window.location.href = waLink(text);
    }
  }

  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-4 rounded-[22px] border border-line bg-card p-5 md:p-7">
      <label className="grid gap-1.5 text-[.88rem] font-medium">
        Your name
        <input name="name" autoComplete="name" placeholder="John Carter" required className={field} />
      </label>
      <label className="grid gap-1.5 text-[.88rem] font-medium">
        Email or phone
        <input name="contact" autoComplete="email" placeholder="john@company.com or +1 555 123 4567" required className={field} />
      </label>
      <label className="grid gap-1.5 text-[.88rem] font-medium">
        Your message
        <textarea name="message" rows={4} placeholder="We miss calls after hours and lose new customers." required className={`${field} min-h-28 resize-y`} />
      </label>

      <p role="alert" className={`text-[.85rem] text-[#A32D2D] ${error ? "" : "hidden"}`}>{error}</p>

      <div className="grid gap-2.5 sm:grid-cols-2">
        <button type="submit" onClick={() => (via.current = "wa")} className="btn btn-wa w-full">
          <BrandIcon name="whatsapp" className="h-[19px] w-[19px]" /> Send on WhatsApp
        </button>
        <button type="submit" onClick={() => (via.current = "email")} className="btn btn-outline w-full">
          <Icon name="mail" className="h-[19px] w-[19px]" /> Send by Email
        </button>
      </div>
      <p className="text-center text-[.8rem] text-mut">Your message opens in WhatsApp or your email app, ready to send.</p>
    </form>
  );
}
