"use client";

import { useEffect, useRef } from "react";

/**
 * Plays a small Lottie animation from /public/lottie.
 * The Lottie library is only downloaded when the animation scrolls into view,
 * so it never slows down the first page load. Used in max 2-3 places.
 */
export function LottiePlayer({ src, label, className = "" }: { src: string; label: string; className?: string }) {
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = box.current;
    if (!el) return;
    let destroy: (() => void) | undefined;
    let cancelled = false;

    const start = async () => {
      try {
        const [{ default: lottie }, data] = await Promise.all([
          // "light" player: draws SVG shapes only, about half the download size of the full player.
          import("lottie-web/build/player/lottie_light"),
          fetch(src).then((r) => r.json()),
        ]);
        if (cancelled || !box.current) return;
        const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        const anim = lottie.loadAnimation({
          container: box.current,
          renderer: "svg",
          loop: !reduce,
          autoplay: !reduce,
          animationData: data,
          rendererSettings: { preserveAspectRatio: "xMidYMid meet" },
        });
        if (reduce) anim.goToAndStop(0, true);
        destroy = () => anim.destroy();
      } catch {
        // If the animation cannot load, the box simply stays empty. The page still works.
      }
    };

    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          io.disconnect();
          start();
        }
      },
      { rootMargin: "200px" }
    );
    io.observe(el);

    return () => {
      cancelled = true;
      io.disconnect();
      destroy?.();
    };
  }, [src]);

  return <div ref={box} role="img" aria-label={label} className={className} />;
}
