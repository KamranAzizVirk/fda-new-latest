"use client";

import { useEffect, useRef, useState } from "react";
import { HELLO_URL, SITE } from "@/lib/site";
import { BotGlyph, OPEN_CHAT_EVENT } from "./FloatingActions";

type Msg = { role: "user" | "assistant"; content: string };

const WELCOME =
  "Welcome to FDE - AI Automation Agency. I can answer your questions about our services, how we work, and how to get started. How may I help you?";

const SUGGESTIONS = ["What services do you offer?", "How does your process work?", "How much does it cost?", "Do you work with my type of business?"];

const LIMIT_MESSAGE = `You have reached the message limit for now. Please try again later, or contact our team on WhatsApp (${SITE.phoneDisplay}) or email ${SITE.email}.`;

const FALLBACK = `I am sorry, the assistant is not available right now. Please contact our team on WhatsApp (${SITE.phoneDisplay}) or email ${SITE.email}.`;

export function ChatAgent({ initialOpen = false }: { initialOpen?: boolean }) {
  const [open, setOpen] = useState(initialOpen);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const onOpen = () => setOpen(true);
    window.addEventListener(OPEN_CHAT_EVENT, onOpen);
    return () => window.removeEventListener(OPEN_CHAT_EVENT, onOpen);
  }, []);

  // Remember which button opened the chat, and give keyboard focus back to it when the chat closes.
  const openerRef = useRef<HTMLElement | null>(null);
  useEffect(() => {
    if (open) {
      const a = document.activeElement as HTMLElement | null;
      if (a && a !== document.body && !a.closest('[role="dialog"]')) openerRef.current = a;
    } else if (openerRef.current?.isConnected) {
      openerRef.current.focus();
      openerRef.current = null;
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    inputRef.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight });
  }, [messages, busy]);

  async function send(text: string) {
    const content = text.trim();
    if (!content || busy) return;
    const next: Msg[] = [...messages, { role: "user", content }];
    setMessages([...next, { role: "assistant", content: "" }]);
    setInput("");
    setBusy(true);

    let reply = "";
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next }),
      });
      if (res.status === 429) {
        setMessages([...next, { role: "assistant", content: LIMIT_MESSAGE }]);
        return;
      }
      if (!res.ok || !res.body) throw new Error("unavailable");
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        reply += decoder.decode(value, { stream: true });
        setMessages([...next, { role: "assistant", content: reply }]);
      }
      if (!reply.trim()) throw new Error("empty");
    } catch {
      setMessages([...next, { role: "assistant", content: FALLBACK }]);
    } finally {
      setBusy(false);
    }
  }

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="false"
      aria-label="FDE AI assistant"
      className="fixed inset-x-0 bottom-0 top-16 z-[60] flex flex-col overflow-hidden border border-line bg-card shadow-[0_30px_70px_-30px_rgba(40,30,10,.55)] sm:inset-x-auto sm:bottom-24 sm:right-5 sm:top-auto sm:h-[560px] sm:max-h-[calc(100vh-8rem)] sm:w-[380px] sm:rounded-[22px] lg:bottom-[150px]"
    >
      <div className="flex items-center gap-3 bg-ink px-4 py-3.5 text-[#F6F1E6]">
        <span className="grid h-9 w-9 place-items-center rounded-full bg-gold-on-dark/15 text-gold-on-dark"><BotGlyph className="h-5 w-5" /></span>
        <div className="flex-1 leading-tight">
          <p className="font-semibold">FDE AI Assistant</p>
          <p className="flex items-center gap-1.5 text-[.75rem] text-[#C9C2B3]"><i className="live-dot !h-1.5 !w-1.5 !shadow-none" />Online, answers instantly</p>
        </div>
        <button type="button" onClick={() => setOpen(false)} aria-label="Close assistant" className="grid h-9 w-9 place-items-center rounded-full hover:bg-white/10">
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18" /></svg>
        </button>
      </div>

      <div ref={listRef} className="flex-1 space-y-3 overflow-y-auto bg-bg px-4 py-4" aria-live="polite">
        <Bubble role="assistant">{WELCOME}</Bubble>
        {messages.length === 0 && (
          <div className="flex flex-wrap gap-2 pt-1">
            {SUGGESTIONS.map((s) => (
              <button key={s} type="button" onClick={() => send(s)} className="rounded-full border border-line bg-card px-3 py-1.5 text-left text-[.82rem] hover:border-gold">
                {s}
              </button>
            ))}
          </div>
        )}
        {messages.map((m, i) =>
          m.role === "assistant" && !m.content ? (
            <Bubble key={i} role="assistant"><span className="chat-dots" aria-label="Typing"><i /><i /><i /></span></Bubble>
          ) : (
            <Bubble key={i} role={m.role}>{m.content}</Bubble>
          )
        )}
      </div>

      <form
        onSubmit={(e) => { e.preventDefault(); send(input); }}
        className="flex items-center gap-2 border-t border-line bg-card p-3"
      >
        <input
          ref={inputRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          maxLength={1000}
          placeholder="Type your question..."
          aria-label="Your question"
          className="min-w-0 flex-1 rounded-full border border-line bg-white px-4 py-2.5 text-base focus:border-gold focus:outline-none focus:ring-[3px] focus:ring-gold/20"
        />
        <button type="submit" disabled={busy || !input.trim()} aria-label="Send" className="grid h-10 w-10 flex-none place-items-center rounded-full bg-gold text-ink disabled:opacity-40">
          <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6" /></svg>
        </button>
      </form>
      <p className="bg-card px-4 pb-3 text-center text-[.72rem] text-mut">
        AI answers can be wrong. For a quote, <a href={HELLO_URL} target="_blank" rel="noopener noreferrer" className="font-semibold text-wa underline">message us on WhatsApp</a>.
      </p>
    </div>
  );
}

function Bubble({ role, children }: { role: "user" | "assistant"; children: React.ReactNode }) {
  const mine = role === "user";
  return (
    <div className={`flex ${mine ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[85%] whitespace-pre-wrap px-3.5 py-2.5 text-[.9rem] leading-relaxed ${
          mine ? "rounded-[16px_16px_4px_16px] bg-gold-l text-ink" : "rounded-[4px_16px_16px_16px] bg-ink text-[#F6F1E6]"
        }`}
      >
        {children}
      </div>
    </div>
  );
}
