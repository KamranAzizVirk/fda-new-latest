"use client";

// Full-page AI chat (opens in a new tab from the robot buttons).
// It uses the same protected /api/chat endpoint as the Home chat: same-site check, size limits and
// message limits (6 per minute, 30 per hour, 60 per day) are all enforced on the server, unchanged.
// Voice typing uses the browser's own speech recognition (no audio is sent to our server).

import { useEffect, useRef, useState } from "react";
import { HELLO_URL, SITE } from "@/lib/site";

type Msg = { role: "user" | "assistant"; content: string };
type Problem = { kind: "limit" | "error"; text: string } | null;

const WELCOME =
  "Hi, I'm FDE AI Assistant. I help businesses automate with AI Voice Agents, AI Chat Agents and Workflow Automation. How can I help automate your business today?";
const SUGGESTIONS = ["What services do you offer?", "How does your process work?", "How much does it cost?", "Do you work with my type of business?"];
const CONTACT = `You can also reach our team on WhatsApp (${SITE.phoneDisplay}) or email ${SITE.email}.`;
const FIRST_REPLY_TIMEOUT_MS = 15_000;

function waitText(seconds: number) {
  if (!Number.isFinite(seconds) || seconds <= 0) return "later";
  if (seconds < 90) return "in about a minute";
  const minutes = Math.ceil(seconds / 60);
  if (minutes < 90) return `in about ${minutes} minutes`;
  return `in about ${Math.ceil(minutes / 60)} hours`;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function getRecognition(): any | null {
  if (typeof window === "undefined") return null;
  const w = window as any;
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

function Robot({ size }: { size: number }) {
  return (
    <span className="grid flex-none place-items-center overflow-hidden rounded-full bg-black shadow-[0_0_0_2px_rgba(56,189,248,.35),0_0_14px_3px_rgba(56,189,248,.35)]" style={{ width: size, height: size }}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/lottie/robot-icon.webp" width={size} height={size} alt="" decoding="async" className="h-full w-full object-cover" />
    </span>
  );
}

export function FullChat() {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [streaming, setStreaming] = useState("");
  const [problem, setProblem] = useState<Problem>(null);
  const [listening, setListening] = useState(false);
  const [micMsg, setMicMsg] = useState("");
  const [canMic, setCanMic] = useState(false);
  const sending = useRef(false);
  const abortRef = useRef<AbortController | null>(null);
  const recRef = useRef<any>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setCanMic(!!getRecognition());
    inputRef.current?.focus();
    return () => {
      abortRef.current?.abort();
      recRef.current?.abort?.();
    };
  }, []);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight });
  }, [messages, streaming, busy, problem]);

  async function request(history: Msg[]) {
    if (sending.current) return;
    sending.current = true;
    setBusy(true);
    setProblem(null);
    setStreaming("");
    const controller = new AbortController();
    abortRef.current = controller;
    const timer = window.setTimeout(() => controller.abort(), FIRST_REPLY_TIMEOUT_MS);
    let reply = "";
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agent: "home", messages: history }),
        signal: controller.signal,
      });
      if (res.status === 429) {
        const wait = Number(res.headers.get("Retry-After"));
        setProblem({ kind: "limit", text: `You've reached the message limit for now. Please try again ${waitText(wait)}. ${CONTACT}` });
        return;
      }
      if (!res.ok || !res.body) throw new Error("unavailable");
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        window.clearTimeout(timer);
        reply += decoder.decode(value, { stream: true });
        setStreaming(reply);
      }
      if (!reply.trim()) throw new Error("empty");
      setMessages([...history, { role: "assistant", content: reply.trim() }]);
    } catch {
      if (reply.trim()) {
        setMessages([...history, { role: "assistant", content: reply.trim() }]);
      } else {
        const timedOut = controller.signal.aborted;
        setProblem({ kind: "error", text: `${timedOut ? "The assistant is taking too long to answer." : "The assistant could not answer right now."} Please try again. ${CONTACT}` });
      }
    } finally {
      window.clearTimeout(timer);
      abortRef.current = null;
      setStreaming("");
      setBusy(false);
      sending.current = false;
    }
  }

  function send(text: string) {
    const content = text.trim();
    if (!content || sending.current) return;
    recRef.current?.stop?.();
    const history: Msg[] = [...messages, { role: "user", content }];
    setMessages(history);
    setInput("");
    void request(history);
  }

  function retry() {
    if (sending.current || messages.length === 0 || messages[messages.length - 1].role !== "user") return;
    void request(messages);
  }

  function toggleMic() {
    setMicMsg("");
    if (listening) {
      recRef.current?.stop?.();
      return;
    }
    const SR = getRecognition();
    if (!SR) {
      setMicMsg("Voice typing is not supported in this browser. Please type your message.");
      return;
    }
    const rec = new SR();
    rec.lang = "en-US";
    rec.interimResults = true;
    rec.continuous = false;
    const base = input.trim();
    rec.onresult = (e: any) => {
      let text = "";
      for (let i = 0; i < e.results.length; i++) text += e.results[i][0].transcript;
      setInput((base ? base + " " : "") + text.trim());
    };
    rec.onerror = (e: any) => {
      setMicMsg(e.error === "not-allowed" || e.error === "service-not-allowed" ? "Microphone is blocked. Please allow it in your browser, or type your message." : "Could not hear you. Please try again or type your message.");
    };
    rec.onend = () => {
      setListening(false);
      inputRef.current?.focus();
    };
    recRef.current = rec;
    try {
      rec.start();
      setListening(true);
    } catch {
      setListening(false);
    }
  }

  return (
    <div className="fixed inset-0 z-[70] flex flex-col bg-bg">
      <header className="flex items-center gap-3 border-b border-line bg-card px-4 py-3 sm:px-6">
        <Robot size={48} />
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-[1.05rem] font-semibold leading-tight tracking-normal text-ink">FDE AI Assistant - Online</h1>
          <p className="flex items-center gap-1.5 text-[.8rem] text-mut">
            <i className="inline-block h-2 w-2 rounded-full bg-wa-bright" aria-hidden="true" />
            Automated AI assistant
          </p>
        </div>
        <a href="/" className="rounded-full border border-line px-4 py-2 text-sm font-semibold text-ink hover:border-gold">
          Back to website
        </a>
      </header>

      <div ref={listRef} role="log" aria-live="polite" aria-label="Conversation" className="flex-1 overflow-y-auto px-4 py-6 sm:px-6">
        <div className="mx-auto flex w-full max-w-3xl flex-col gap-4">
          <div className="flex items-end gap-2.5">
            <Robot size={36} />
            <div className="max-w-[85%] rounded-2xl rounded-bl-md border border-line bg-card px-4 py-3 text-[1rem] leading-relaxed text-ink">{WELCOME}</div>
          </div>

          {messages.length === 0 && !busy && (
            <div className="flex flex-wrap gap-2 pl-[46px]">
              {SUGGESTIONS.map((q) => (
                <button key={q} type="button" onClick={() => send(q)} className="rounded-full border border-line bg-card px-4 py-2 text-sm text-ink hover:border-gold">
                  {q}
                </button>
              ))}
            </div>
          )}

          {messages.map((m, i) =>
            m.role === "user" ? (
              <div key={i} className="flex justify-end">
                <div className="max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-br-md bg-ink px-4 py-3 text-[1rem] leading-relaxed text-[#F6F1E6]">{m.content}</div>
              </div>
            ) : (
              <div key={i} className="flex items-end gap-2.5">
                <Robot size={36} />
                <div className="max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-bl-md border border-line bg-card px-4 py-3 text-[1rem] leading-relaxed text-ink">{m.content}</div>
              </div>
            )
          )}

          {busy && (
            <div className="flex items-end gap-2.5">
              <Robot size={36} />
              <div className="max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-bl-md border border-line bg-card px-4 py-3 text-[1rem] leading-relaxed text-ink">{streaming || <span className="text-mut">Getting your answer&hellip;</span>}</div>
            </div>
          )}

          {problem && !busy && (
            <div className="flex items-end gap-2.5" role="status">
              <Robot size={36} />
              <div className="max-w-[85%] rounded-2xl rounded-bl-md border border-gold bg-gold-l px-4 py-3 text-[.95rem] leading-relaxed text-ink">
                {problem.text}
                {problem.kind === "error" && (
                  <>
                    <br />
                    <button type="button" onClick={retry} className="mt-2 rounded-full border border-gold-d px-3 py-1 text-sm font-semibold text-gold-d">
                      Try again
                    </button>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      <footer className="border-t border-line bg-card px-4 pt-3 pb-[calc(12px+env(safe-area-inset-bottom))] sm:px-6">
        <form
          className="mx-auto flex w-full max-w-3xl items-center gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
        >
          <input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            maxLength={1000}
            placeholder={listening ? "Listening... speak now" : "Type or speak your question..."}
            aria-label="Your question"
            autoComplete="off"
            enterKeyHint="send"
            className="h-12 min-w-0 flex-1 rounded-full border border-line bg-bg px-5 text-[1rem] text-ink outline-none focus:border-gold"
          />
          {canMic && (
            <button
              type="button"
              onClick={toggleMic}
              aria-label={listening ? "Stop voice typing" : "Start voice typing"}
              aria-pressed={listening}
              className={`grid h-12 w-12 flex-none place-items-center rounded-full border ${listening ? "border-red-500 bg-red-500 text-white" : "border-line bg-bg text-ink hover:border-gold"}`}
            >
              <svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <rect x="9" y="3" width="6" height="11" rx="3" />
                <path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3" />
              </svg>
            </button>
          )}
          <button type="submit" disabled={busy || !input.trim()} aria-label="Send" className="grid h-12 w-12 flex-none place-items-center rounded-full bg-ink text-[#F6F1E6] disabled:opacity-40">
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth={2.1} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M12 19V5M5.5 11.5 12 5l6.5 6.5" />
            </svg>
          </button>
        </form>
        {micMsg && <p className="mx-auto mt-2 max-w-3xl text-center text-sm text-mut" role="status">{micMsg}</p>}
        <p className="mx-auto mt-2 max-w-3xl text-center text-[.78rem] text-mut">
          AI answers can be wrong. For a quote,{" "}
          <a href={HELLO_URL} target="_blank" rel="noopener noreferrer" className="underline">
            message us on WhatsApp
          </a>
          .
        </p>
      </footer>
    </div>
  );
}
