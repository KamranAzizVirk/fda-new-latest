"use client";

// Comments box at the bottom of the Home page.
// - Anyone can read APPROVED comments. Only logged-in (Google) visitors can write.
// - New comments are hidden until Kamran approves them in Supabase (approved = true).
// - Comments are read with one small request when the visitor scrolls near this box (no extra code on first load).

import { useEffect, useRef, useState } from "react";
import { AUTH_READY, SUPABASE_ANON_KEY, SUPABASE_URL, getSupabase, setLoginOpen, useAuth } from "@/lib/auth";
import { GoogleMark, UserAvatar } from "./AuthButton";
import { Eyebrow } from "./ui";

type Comment = { id: number; name: string; avatar_url: string | null; body: string; created_at: string };
const MAX = 1000;

function niceDate(iso: string) {
  try {
    return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  } catch {
    return "";
  }
}

function CommentCard({ c, pending = false }: { c: Comment; pending?: boolean }) {
  return (
    <li className={`flex gap-3.5 rounded-[18px] border bg-card p-5 sm:p-6 ${pending ? "border-gold/60 border-dashed" : "border-line"}`}>
      <UserAvatar user={{ name: c.name, avatar: c.avatar_url && /^https:\/\//.test(c.avatar_url) ? c.avatar_url : null }} size={44} />
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-baseline gap-x-2.5 gap-y-0.5">
          <p className="font-semibold text-ink">{c.name}</p>
          <p className="text-[.8rem] text-mut">{niceDate(c.created_at)}</p>
          {pending && <span className="rounded-full bg-gold-l px-2.5 py-0.5 text-[.72rem] font-semibold text-gold-d">Waiting for approval</span>}
        </div>
        <p className="mt-1.5 whitespace-pre-wrap break-words text-[.97rem] leading-relaxed text-ink/90">{c.body}</p>
      </div>
    </li>
  );
}

export function CommentsSection() {
  const { status, user } = useAuth();
  const box = useRef<HTMLElement>(null);
  const [list, setList] = useState<Comment[] | null>(null);
  const [loadErr, setLoadErr] = useState(false);
  const [mine, setMine] = useState<Comment[]>([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  // Load approved comments only when the visitor scrolls near this box.
  useEffect(() => {
    const el = box.current;
    if (!el || !AUTH_READY) return;
    let io: IntersectionObserver | undefined;
    const load = async () => {
      try {
        const res = await fetch(`${SUPABASE_URL}/rest/v1/comments?select=id,name,avatar_url,body,created_at&approved=eq.true&order=created_at.desc&limit=50`, {
          headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${SUPABASE_ANON_KEY}` },
        });
        if (!res.ok) throw new Error(String(res.status));
        setList((await res.json()) as Comment[]);
      } catch {
        setLoadErr(true);
        setList([]);
      }
    };
    const watch = () => {
      window.removeEventListener("scroll", watch);
      io = new IntersectionObserver(
        ([e]) => {
          if (e.isIntersecting) {
            io?.disconnect();
            void load();
          }
        },
        { rootMargin: "600px" }
      );
      io.observe(el);
    };
    window.addEventListener("scroll", watch, { once: true, passive: true });
    return () => {
      window.removeEventListener("scroll", watch);
      io?.disconnect();
    };
  }, []);

  async function post(e: React.FormEvent) {
    e.preventDefault();
    const body = text.trim();
    if (!body || busy || !user) return;
    setBusy(true);
    setMsg(null);
    try {
      const sb = await getSupabase();
      if (!sb) throw new Error("not-ready");
      const { error } = await sb.from("comments").insert({ body });
      if (error) throw error;
      setMine((m) => [{ id: -Date.now(), name: user.name, avatar_url: user.avatar, body, created_at: new Date().toISOString() }, ...m]);
      setText("");
      setMsg({ ok: true, text: "Thank you! Your comment will appear here after approval." });
    } catch (err) {
      const t = String((err as { message?: string })?.message || "");
      setMsg({ ok: false, text: /too many/i.test(t) ? "You have posted a few comments already. Please try again later." : "Your comment could not be posted. Please try again." });
    } finally {
      setBusy(false);
    }
  }

  const shown = list ?? [];

  return (
    <section ref={box} id="comments" aria-labelledby="comments-title" className="py-16 lg:py-24">
      <div className="wrap max-w-3xl">
        <Eyebrow>Comments</Eyebrow>
        <h2 id="comments-title" className="text-[clamp(1.8rem,4.8vw,2.65rem)]">Leave a comment</h2>
        <p className="mt-2 text-mut">Share your thoughts or questions. Comments appear after a short review.</p>

        <div className="mt-8 rounded-[22px] border border-line bg-card p-5 shadow-[0_24px_50px_-36px_rgba(26,26,26,.45)] sm:p-7">
          {status === "in" && user ? (
            <form onSubmit={post}>
              <div className="flex items-center gap-3">
                <UserAvatar user={user} size={40} />
                <div className="min-w-0">
                  <p className="truncate font-semibold">{user.name}</p>
                  <p className="text-[.8rem] text-mut">Posting as you</p>
                </div>
              </div>
              <label htmlFor="comment-text" className="sr-only">Your comment</label>
              <textarea
                id="comment-text"
                value={text}
                onChange={(e) => setText(e.target.value.slice(0, MAX))}
                rows={4}
                maxLength={MAX}
                placeholder="Write your comment..."
                className="mt-4 w-full resize-y rounded-2xl border border-line bg-bg px-4 py-3 text-[1rem] leading-relaxed text-ink outline-none transition-colors focus:border-gold"
              />
              <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                <span className="text-[.78rem] text-mut">{text.length}/{MAX}</span>
                <button type="submit" disabled={busy || !text.trim()} className="btn btn-gold !min-h-11 !px-6 disabled:opacity-50">
                  {busy ? "Posting..." : "Post comment"}
                </button>
              </div>
              {msg && (
                <p role="status" className={`mt-3 rounded-xl px-4 py-2.5 text-[.9rem] ${msg.ok ? "bg-gold-l text-ink" : "border border-line bg-bg text-ink"}`}>
                  {msg.text}
                </p>
              )}
            </form>
          ) : (
            <div className="flex flex-col items-center gap-4 py-2 text-center sm:flex-row sm:justify-between sm:text-left">
              <div>
                <p className="font-semibold">Want to join the conversation?</p>
                <p className="mt-0.5 text-[.92rem] text-mut">Log in with Google to write a comment.</p>
              </div>
              <button
                type="button"
                onClick={() => setLoginOpen(true)}
                className="flex h-12 flex-none items-center gap-3 rounded-full border border-line bg-white px-5 text-[.95rem] font-semibold text-ink shadow-[0_6px_18px_-12px_rgba(26,26,26,.5)] hover:border-gold"
              >
                <GoogleMark />
                Continue with Google
              </button>
            </div>
          )}
        </div>

        <ul className="mt-6 grid gap-4" aria-label="Comments">
          {mine.map((c) => (
            <CommentCard key={c.id} c={c} pending />
          ))}
          {shown.map((c) => (
            <CommentCard key={c.id} c={c} />
          ))}
        </ul>
        {list !== null && shown.length === 0 && mine.length === 0 && (
          <p className="mt-6 rounded-[18px] border border-dashed border-line px-5 py-6 text-center text-mut">
            {loadErr ? "Comments could not be loaded right now." : "No comments yet. Be the first to share your thoughts."}
          </p>
        )}
      </div>
    </section>
  );
}
