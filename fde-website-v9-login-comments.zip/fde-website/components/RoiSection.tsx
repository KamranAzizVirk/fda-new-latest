"use client";

import dynamic from "next/dynamic";
import { useEffect, useRef, useState } from "react";

// The calculator's code is split into its own small file and only downloaded
// when the visitor scrolls near it, so it never slows the first page load.
const RoiCalculator = dynamic(() => import("./RoiCalculator"), {
  ssr: false,
  loading: () => <Placeholder />,
});

function Placeholder() {
  return <div aria-hidden="true" className="h-[730px] rounded-[20px] border border-line bg-card/60 max-[379px]:h-[800px] lg:h-[410px]" />;
}

export function RoiSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [show, setShow] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (!("IntersectionObserver" in window)) return setShow(true);
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setShow(true);
          io.disconnect();
        }
      },
      { rootMargin: "400px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return <div ref={ref}>{show ? <RoiCalculator /> : <Placeholder />}</div>;
}
