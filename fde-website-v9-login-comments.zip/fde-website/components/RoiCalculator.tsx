"use client";

import { useId, useState } from "react";
import { ROI } from "@/lib/content";
import { waLink } from "@/lib/site";
import { Icon } from "./Icon";

type Key = keyof typeof ROI.fields;

const usd = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });

// Average weeks in a month (52 weeks / 12 months).
const WEEKS_PER_MONTH = 52 / 12;

function clamp(n: number, min: number, max: number) {
  if (!Number.isFinite(n)) return min;
  return Math.min(max, Math.max(min, n));
}

/** The interactive part of the missed-call calculator. Loaded only when scrolled near. */
export default function RoiCalculator() {
  const [vals, setVals] = useState<Record<Key, number>>({
    missed: ROI.fields.missed.start,
    rate: ROI.fields.rate.start,
    value: ROI.fields.value.start,
  });

  const perWeek = vals.missed * (vals.rate / 100) * vals.value;
  const perMonth = perWeek * WEEKS_PER_MONTH;
  const perYear = perWeek * 52;

  const message =
    `Hi FDE - AI Automation Agency, I used the missed-call calculator on your website. ` +
    `My numbers: about ${vals.missed} missed calls or late replies per week, ${vals.rate}% would become customers, ` +
    `average customer value ${usd.format(vals.value)}. I'd like to book a free call.`;

  return (
    <div className="grid gap-5 lg:grid-cols-[1.1fr_.9fr]">
      <div className="grid gap-5 rounded-[20px] border border-line bg-card p-5 md:p-7">
        {(Object.keys(ROI.fields) as Key[]).map((k) => (
          <Field key={k} k={k} value={vals[k]} onChange={(v) => setVals((s) => ({ ...s, [k]: v }))} />
        ))}
        <p className="text-[.8rem] text-mut">{ROI.startNote}</p>
      </div>

      <div className="flex flex-col justify-between rounded-[20px] bg-ink p-6 text-[#F6F1E6] md:p-8">
        <div aria-live="polite">
          <p className="text-[.74rem] font-semibold uppercase tracking-[.12em] text-gold-on-dark">{ROI.resultLabel}</p>
          <p className="mt-3 text-[clamp(2.2rem,8vw,3.2rem)] font-semibold leading-none tracking-[-.03em] tabular-nums">
            {usd.format(perMonth)}
            <span className="ml-2 text-[1rem] font-medium tracking-normal text-[#C9C2B3]">{ROI.perMonth}</span>
          </p>
          <p className="mt-3 text-[1.05rem] tabular-nums text-[#D9D2C3]">
            {usd.format(perYear)} <span className="text-[#A8A091]">{ROI.perYear}</span>
          </p>
        </div>
        <div className="mt-7">
          <p className="mb-5 text-[.82rem] leading-relaxed text-[#A8A091]">{ROI.disclaimer}</p>
          <a
            href={waLink(message)}
            target="_blank"
            rel="noopener noreferrer"
            className="btn w-full bg-gold-on-dark text-ink hover:bg-[#E8C676] sm:w-auto"
          >
            <Icon name="calendar" className="h-[18px] w-[18px]" />
            {ROI.button}
          </a>
        </div>
      </div>
    </div>
  );
}

function Field({ k, value, onChange }: { k: Key; value: number; onChange: (v: number) => void }) {
  const f = ROI.fields[k];
  const id = useId();
  const pct = f.max ? ((value - f.min) / (f.max - f.min)) * 100 : 0;
  return (
    <div>
      <div className="flex items-center justify-between gap-3">
        <label htmlFor={id} className="text-[.92rem] font-medium leading-snug">{f.label}</label>
        <input
          id={id}
          type="number"
          inputMode="numeric"
          min={f.min}
          max={f.max}
          step={f.step}
          value={Number.isFinite(value) ? value : ""}
          onChange={(e) => onChange(clamp(e.target.valueAsNumber, f.min, f.max))}
          className="w-[6.5rem] flex-none rounded-[10px] border border-line bg-white px-3 py-2 text-right text-base font-semibold tabular-nums focus:border-gold focus:outline-none focus:ring-[3px] focus:ring-gold/20"
        />
      </div>
      <input
        type="range"
        aria-label={f.label}
        min={f.min}
        max={k === "value" ? 5000 : f.max}
        step={f.step}
        value={Math.min(value, k === "value" ? 5000 : f.max)}
        onChange={(e) => onChange(Number(e.target.value))}
        className="roi-range mt-3 w-full"
        style={{ "--p": `${k === "value" ? Math.min(100, (value / 5000) * 100) : pct}%` } as React.CSSProperties}
      />
    </div>
  );
}
