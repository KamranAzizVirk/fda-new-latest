import type { IconName } from "@/lib/content";
import { BRAND_ICONS } from "@/lib/logos";

const PATHS: Record<IconName, React.ReactNode> = {
  voice: (<><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21M8.5 21h7" /></>),
  flow: (<><rect x="3" y="4" width="6" height="6" rx="1.5" /><rect x="15" y="14" width="6" height="6" rx="1.5" /><path d="M9 7h4a2 2 0 0 1 2 2v5" /></>),
  target: (<><circle cx="12" cy="12" r="8.5" /><circle cx="12" cy="12" r="4.5" /><circle cx="12" cy="12" r=".6" /></>),
  sheet: (<><rect x="4.5" y="3.5" width="15" height="17" rx="2.5" /><path d="M4.5 9.5h15M4.5 14.5h15M10.5 9.5v11" /></>),
  design: (<><path d="M12 3.5a8.5 8.5 0 1 0 0 17c1.2 0 1.8-.9 1.4-1.9-.5-1.2.3-2.1 1.5-2.1h1.6a4 4 0 0 0 4-4c0-5-3.8-9-8.5-9z" /><circle cx="7.8" cy="11" r="1" /><circle cx="10.5" cy="7.4" r="1" /><circle cx="15" cy="8" r="1" /></>),
  screen: (<><rect x="2.5" y="4" width="13" height="10" rx="1.5" /><path d="M6 18h6" /><rect x="17" y="8" width="4.5" height="11" rx="1.2" /></>),
  search: (<><circle cx="10.5" cy="10.5" r="6.5" /><path d="M15.5 15.5 20.5 20.5" /></>),
  plan: (<><path d="M8 4h8M9 3h6v3H9z" /><rect x="5" y="4.5" width="14" height="16" rx="2" /><path d="M8.5 11h7M8.5 14.5h7M8.5 18h4" /></>),
  build: (<><path d="M14.5 6.5a4 4 0 0 0-5.3 5.3L4 17l3 3 5.2-5.2a4 4 0 0 0 5.3-5.3l-2.4 2.4-2.6-.4-.4-2.6z" /></>),
  support: (<><path d="M4 13v-1a8 8 0 0 1 16 0v1" /><rect x="3" y="13" width="4" height="6" rx="1.5" /><rect x="17" y="13" width="4" height="6" rx="1.5" /><path d="M19 19a3 3 0 0 1-3 2.5h-2.5" /></>),
  phone: (<><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2" /></>),
  clock: (<><circle cx="12" cy="12" r="8.5" /><path d="M12 7.5V12l3 2" /></>),
  copy: (<><rect x="8" y="8" width="12" height="12" rx="2" /><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2" /></>),
  shield: (<><path d="M12 3 5 6v5.5c0 4.3 2.9 8.2 7 9.5 4.1-1.3 7-5.2 7-9.5V6z" /><path d="m9 12 2 2 4-4" /></>),
  spark: (<><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6" /></>),
  globe: (<><circle cx="12" cy="12" r="8.5" /><path d="M3.5 12h17M12 3.5c2.5 2.6 3.5 5.4 3.5 8.5s-1 5.9-3.5 8.5c-2.5-2.6-3.5-5.4-3.5-8.5s1-5.9 3.5-8.5z" /></>),
  check: (<path d="M5 12.5l4.5 4.5L19 7.5" />),
  mail: (<><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3.5 7l8.5 6 8.5-6" /></>),
  calendar: (<><rect x="3.5" y="5" width="17" height="15" rx="2" /><path d="M3.5 10h17M8 3v4M16 3v4" /></>),
  pin: (<><path d="M12 21s-6.5-5.6-6.5-11a6.5 6.5 0 0 1 13 0C18.5 15.4 12 21 12 21z" /><circle cx="12" cy="10" r="2.3" /></>),
};

type Props = {
  name: IconName;
  className?: string;
  /** Gentle idle movement (CSS only). */
  animate?: boolean;
};

// Each icon type gets its own start offset, so icons on a page do not bob in sync.
function offset(name: string) {
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) % 997;
  return `-${(h % 36) / 10}s`;
}

export function Icon({ name, className = "h-5 w-5", animate = false }: Props) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      className={`${className}${animate ? " icon-float" : ""}`}
      style={animate ? { animationDelay: offset(name) } : undefined}
    >
      {PATHS[name]}
    </svg>
  );
}

/** WhatsApp / LinkedIn marks (single colour, follow currentColor). */
export function BrandIcon({ name, className = "h-5 w-5" }: { name: keyof typeof BRAND_ICONS; className?: string }) {
  return <span className={`inline-flex ${className} [&>svg]:h-full [&>svg]:w-full`} dangerouslySetInnerHTML={{ __html: BRAND_ICONS[name] }} />;
}
