"use client";

import { useEffect, useRef, useState } from "react";
import { BrandIcon } from "./Icon";
import { BotGlyph, openChat } from "./FloatingActions";

/** Hero visual: a live, looping "lead to booked meeting" workflow (SVG + CSS only). */
export function WorkflowCard() {
  const ref = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const [typed, setTyped] = useState(false);
  const [visible, setVisible] = useState(true);

  // Pause the loop while the card is off screen, to save battery.
  useEffect(() => {
    const el = ref.current;
    if (!el || !("IntersectionObserver" in window)) return;
    const io = new IntersectionObserver(([e]) => setVisible(e.isIntersecting));
    io.observe(el);
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    if (!open) { setTyped(false); return; }
    const t = setTimeout(() => setTyped(true), 900);
    return () => clearTimeout(t);
  }, [open]);

  return (
    <div>
      <div ref={ref} className={`wf${open ? " on" : ""}${visible ? "" : " paused"}`}>
        <div className="wf-head">
          Lead to booked meeting
          {/* Original tag text: "Live demo" (changed 2026-11-17 while the Estimator Pro link is hidden) */}
          <span><i className="live-dot" />Demo project</span>
        </div>
        <ol className="st">
          <li className="s1">
            <div className="rw">
              <span className="wi"><BrandIcon name="whatsapp" className="h-5 w-5" /></span>
              <span className="tt"><strong>New lead</strong><small>WhatsApp message</small></span>
              <span className="cp">Received</span>
            </div>
          </li>
          <li className="s2">
            <button type="button" className="rw ag" aria-expanded={open} aria-controls="wf-bubble" onClick={() => setOpen((v) => !v)}>
              <span className="wi"><BotGlyph className="h-5 w-5" /></span>
              <span className="tt"><strong><span className="whitespace-nowrap">AI Agent</span> {!open && <em>Tap me</em>}</strong><small>Answers and qualifies the lead</small></span>
              <span className="cp">Replied</span>
            </button>
            <div className="bub" id="wf-bubble" role="status">
              <span className="bb">
                {typed ? (
                  <>
                    Hello, I am the FDE AI assistant. How may I help you today?
                    <br />
                    <button type="button" onClick={openChat}>Ask me a question &rarr;</button>
                  </>
                ) : (
                  <span className="typing" aria-label="Typing"><i /><i /><i /></span>
                )}
              </span>
            </div>
          </li>
          <li className="s3">
            <div className="rw">
              <span className="wi">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><rect x="4.5" y="3.5" width="15" height="17" rx="2.5" /><path d="M4.5 9.5h15M4.5 14.5h15M10.5 9.5v11" /></svg>
              </span>
              <span className="tt"><strong>Saved in Sheet</strong><small>Lead logged</small></span>
              <span className="cp">Saved</span>
            </div>
          </li>
          <li className="s4">
            <div className="rw">
              <span className="wi">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path className="tk" d="M5.5 12.5l4.5 4.5L18.5 7.5" /></svg>
              </span>
              <span className="tt"><strong>Meeting booked</strong><small>On your calendar</small></span>
              <span className="cp">Booked</span>
            </div>
          </li>
        </ol>
      </div>
      <p className="mx-auto mt-4 flex max-w-[400px] flex-wrap items-center justify-center gap-x-2 gap-y-1 text-center text-[.86rem] text-mut">
        <i className="live-dot" />
        <strong className="font-semibold text-ink">Live interactive demo</strong>
        <span>Tap the AI Agent. This is how FDE works 24/7.</span>
      </p>
    </div>
  );
}
