"use client";

import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { AUTH_READY, setLoginOpen, signInWithGoogle, signOut, startAuth, useAuth, useLoginOpen, type AuthUser } from "@/lib/auth";

export function GoogleMark({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z" />
      <path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" />
      <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z" />
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z" />
    </svg>
  );
}

export function UserAvatar({ user, size }: { user: Pick<AuthUser, "name" | "avatar">; size: number }) {
  const [broken, setBroken] = useState(false);
  const initial = (user.name.trim()[0] || "U").toUpperCase();
  return user.avatar && !broken ? (
    // eslint-disable-next-line @next/next/no-img-element
    <img src={user.avatar} alt="" width={size} height={size} referrerPolicy="no-referrer" loading="lazy" decoding="async" onError={() => setBroken(true)} className="flex-none rounded-full border border-line object-cover" style={{ width: size, height: size }} />
  ) : (
    <span aria-hidden="true" className="grid flex-none place-items-center rounded-full bg-gold-l font-semibold text-gold-d" style={{ width: size, height: size, fontSize: size * 0.42 }}>
      {initial}
    </span>
  );
}

export function GoogleButton({ className = "" }: { className?: string }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  return (
    <div className={className}>
      <button
        type="button"
        disabled={busy}
        onClick={async () => {
          setErr("");
          setBusy(true);
          try {
            await signInWithGoogle();
          } catch {
            setBusy(false);
            setErr(AUTH_READY ? "Could not open Google login. Please try again." : "Login is not available yet. Please try again later.");
          }
        }}
        className="flex h-12 w-full items-center justify-center gap-3 rounded-full border border-line bg-white px-5 text-[.95rem] font-semibold text-ink shadow-[0_6px_18px_-12px_rgba(26,26,26,.5)] transition-colors hover:border-gold disabled:opacity-60"
      >
        <GoogleMark />
        {busy ? "Opening Google..." : "Continue with Google"}
      </button>
      {err && <p className="mt-2 text-center text-sm text-mut" role="status">{err}</p>}
    </div>
  );
}

export function LoginDialog() {
  const open = useLoginOpen();
  const box = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setLoginOpen(false);
    window.addEventListener("keydown", esc);
    box.current?.querySelector("button")?.focus();
    return () => window.removeEventListener("keydown", esc);
  }, [open]);
  if (!open) return null;
  // Rendered into <body> so it covers the whole screen (the header's blur effect would otherwise trap it).
  return createPortal(
    <div className="fixed inset-0 z-[80] grid place-items-center bg-ink/40 p-4" onClick={() => setLoginOpen(false)}>
      <div
        ref={box}
        role="dialog"
        aria-modal="true"
        aria-labelledby="login-title"
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-[380px] rounded-[22px] border border-line bg-card p-7 text-center shadow-[0_30px_60px_-30px_rgba(26,26,26,.55)]"
      >
        <button type="button" onClick={() => setLoginOpen(false)} aria-label="Close" className="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full text-mut hover:bg-bg">
          <svg viewBox="0 0 24 24" className="h-4.5 w-4.5" width="18" height="18" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18" /></svg>
        </button>
        <b aria-hidden="true" className="mx-auto grid h-12 w-12 place-items-center rounded-[12px] bg-ink text-[.8rem] font-bold tracking-[.04em] text-gold-on-dark">FDE</b>
        <h2 id="login-title" className="mt-4 text-[1.35rem]">Log in or sign up</h2>
        <p className="mt-1.5 text-[.93rem] text-mut">Use your Google account to join the conversation on FDE.</p>
        <GoogleButton className="mt-6" />
        <p className="mt-4 text-[.78rem] text-mut">We only use your name and profile photo.</p>
      </div>
    </div>,
    document.body
  );
}

function UserIcon({ className }: { className: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="12" cy="8" r="4" />
      <path d="M4.5 20.5a7.5 7.5 0 0 1 15 0" />
    </svg>
  );
}

/** Desktop header (laptop/PC): small black "Login" button, same size as "Book a Call". After login: photo + first name. */
export function AuthButton() {
  const { status, user } = useAuth();
  const [menu, setMenu] = useState(false);
  const wrap = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menu) return;
    const close = (e: MouseEvent) => !wrap.current?.contains(e.target as Node) && setMenu(false);
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setMenu(false);
    document.addEventListener("click", close);
    window.addEventListener("keydown", esc);
    return () => {
      document.removeEventListener("click", close);
      window.removeEventListener("keydown", esc);
    };
  }, [menu]);

  return (
    <div ref={wrap} className="relative hidden lg:block">
      {status === "in" && user ? (
        <>
          <button type="button" onClick={() => setMenu((v) => !v)} aria-haspopup="menu" aria-expanded={menu} aria-label={`Account: ${user.name}`} className="btn btn-ink !min-h-9 !gap-2 !pl-1.5 !pr-3.5 !text-[.82rem]">
            <UserAvatar user={user} size={26} />
            <span className="max-w-[100px] truncate">{user.name.split(" ")[0]}</span>
          </button>
          {menu && (
            <div role="menu" className="absolute right-0 top-[calc(100%+8px)] z-50 w-56 rounded-2xl border border-line bg-card p-2 shadow-[0_20px_40px_-20px_rgba(26,26,26,.45)]">
              <div className="flex items-center gap-2.5 px-2.5 py-2">
                <UserAvatar user={user} size={36} />
                <div className="min-w-0">
                  <p className="truncate text-[.9rem] font-semibold">{user.name}</p>
                  <p className="text-[.76rem] text-mut">Logged in with Google</p>
                </div>
              </div>
              <button
                type="button"
                role="menuitem"
                onClick={async () => {
                  setMenu(false);
                  await signOut();
                }}
                className="mt-1 w-full rounded-xl px-3 py-2.5 text-left text-[.9rem] font-medium hover:bg-bg"
              >
                Log out
              </button>
            </div>
          )}
        </>
      ) : (
        <button type="button" onClick={() => setLoginOpen(true)} aria-label="Login or sign up" className="btn btn-ink !min-h-9 !gap-1.5 !px-3.5 !text-[.82rem]">
          <UserIcon className="h-4 w-4" />
          Login
        </button>
      )}
    </div>
  );
}

/** Phone/tablet: shown at the top of the ☰ menu. */
export function MobileAuthRow({ onDone }: { onDone: () => void }) {
  const { status, user } = useAuth();
  if (status === "in" && user)
    return (
      <div className="mx-5 mb-2 flex items-center gap-3 rounded-2xl border border-line bg-card px-3.5 py-3">
        <UserAvatar user={user} size={38} />
        <div className="min-w-0 flex-1">
          <p className="truncate font-semibold">{user.name}</p>
          <p className="text-[.76rem] text-mut">Logged in with Google</p>
        </div>
        <button
          type="button"
          onClick={async () => {
            await signOut();
            onDone();
          }}
          className="rounded-full border border-line px-3.5 py-2 text-[.85rem] font-semibold"
        >
          Log out
        </button>
      </div>
    );
  return (
    <div className="px-5 pb-2">
      <button
        type="button"
        onClick={() => {
          onDone();
          setLoginOpen(true);
        }}
        aria-label="Login or sign up"
        className="flex h-12 w-full items-center justify-center gap-2 rounded-full border border-line bg-card text-[.95rem] font-semibold text-ink"
      >
        <UserIcon className="h-[18px] w-[18px]" />
        Login / Sign up
      </button>
    </div>
  );
}

/** Mounted once in the header: starts the login check and holds the login box. */
export function AuthRoot() {
  useEffect(() => startAuth(), []);
  return <LoginDialog />;
}
