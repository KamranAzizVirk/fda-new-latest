import Image from "next/image";
import { CEO_MEMBER, DIRECTORS, TEAM_HEADING } from "@/team";
import { Reveal } from "./Reveal";
import { Eyebrow } from "./ui";

type Member = { name: string; title: string; photo?: string };

/** Neutral placeholder: no face, no gender. Shown when a member has no photo. */
function AvatarIcon() {
  return (
    <svg viewBox="0 0 96 96" className="h-full w-full" aria-hidden="true">
      <rect width="96" height="96" fill="var(--color-gold-l)" />
      <circle cx="48" cy="37" r="15" fill="var(--color-gold)" opacity=".85" />
      <path d="M17 96c2-20 14-31 31-31s29 11 31 31z" fill="var(--color-gold)" opacity=".85" />
    </svg>
  );
}

function Portrait({ member, size }: { member: Member; size: number }) {
  const raw = (member.photo || "").trim();
  // Safety: only a file from the public folder ("/photo.jpg") or a secure https link is accepted.
  const photo = /^\/(?!\/)/.test(raw) || /^https:\/\//i.test(raw) ? raw : "";
  const ring = "overflow-hidden rounded-full border-[3px] border-card bg-bg2 shadow-[0_0_0_2px_var(--color-gold)]";
  return (
    <div className="person-ring">
    <div className={ring} style={{ width: size, height: size }}>
      {!photo ? (
        <AvatarIcon />
      ) : photo.startsWith("/") ? (
        <Image src={photo} alt={`${member.name}, ${member.title}`} width={size} height={size} sizes={`${size}px`} className="h-full w-full object-cover" style={{ objectPosition: "50% 18%" }} />
      ) : (
        // Outside photo links are shown as plain lazy-loaded images.
        // eslint-disable-next-line @next/next/no-img-element
        <img src={photo} alt={`${member.name}, ${member.title}`} width={size} height={size} loading="lazy" decoding="async" referrerPolicy="no-referrer" className="h-full w-full object-cover" />
      )}
    </div>
    </div>
  );
}

/** All names, titles and photos come from /team.js. */
export function TeamSection() {
  const directors: Member[] = DIRECTORS;
  return (
    <section id="team" className="border-y border-line bg-card py-16 lg:py-24">
      <div className="wrap">
        <Reveal className="mx-auto max-w-2xl text-center">
          <Eyebrow>Our team</Eyebrow>
          <h2 className="text-[clamp(1.8rem,4.8vw,2.65rem)]">{TEAM_HEADING}</h2>
        </Reveal>

        <Reveal delay={0.05} className="mx-auto mt-10 flex max-w-sm flex-col items-center rounded-[22px] border border-line bg-bg px-6 py-8 text-center">
          <Portrait member={CEO_MEMBER} size={128} />
          <h3 className="mt-5 text-[1.25rem] font-semibold">{CEO_MEMBER.name}</h3>
          <p className="mt-1 text-[.95rem] font-medium text-gold-d">{CEO_MEMBER.title}</p>
        </Reveal>

        <ul className="mt-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {directors.map((d, i) => (
            <li key={`${d.title}-${i}`}>
              <Reveal delay={0.05 + i * 0.06} className="flex h-full flex-col items-center rounded-[18px] border border-line bg-bg px-4 py-7 text-center">
                <Portrait member={d} size={84} />
                <h3 className="mt-4 text-[1rem] font-semibold leading-snug">{d.name}</h3>
                <p className="mt-1 text-[.88rem] font-medium leading-snug text-gold-d">{d.title}</p>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
