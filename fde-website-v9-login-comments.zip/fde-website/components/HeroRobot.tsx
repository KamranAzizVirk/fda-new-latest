"use client";

import { useEffect, useRef, useState } from "react";

/**
 * Hero robot on all screens (half size since v8).
 * A small still picture shows first, then the live Lottie animation takes over
 * after the page has finished loading, so the page speed is not affected.
 * Clicking the robot or "Get Started" opens the full AI chat page in a new tab.
 */
export function HeroRobot() {
  const box = useRef<HTMLDivElement>(null);
  const [live, setLive] = useState(false);

  useEffect(() => {
    const el = box.current;
    if (!el) return;
    let destroy: (() => void) | undefined;
    let cancelled = false;
    let io: IntersectionObserver | undefined;

    const start = async () => {
      if (cancelled) return;
      try {
        const [{ default: lottie }, data] = await Promise.all([
          import("lottie-web/build/player/lottie_light"),
          fetch("/lottie/robot.json").then((r) => r.json()),
        ]);
        if (cancelled) return;
        const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        const anim = lottie.loadAnimation({
          container: el,
          renderer: "svg",
          loop: true,
          autoplay: !reduce,
          animationData: data,
          rendererSettings: { preserveAspectRatio: "xMidYMid meet" },
        });
        if (reduce) anim.goToAndStop(0, true);
        else {
          io = new IntersectionObserver(([e]) => (e.isIntersecting ? anim.play() : anim.pause()));
          io.observe(el);
        }
        setLive(true);
        destroy = () => anim.destroy();
      } catch {
        // The still picture simply stays. The page still works.
      }
    };

    const kick = () => {
      const ric = (window as unknown as { requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => void }).requestIdleCallback;
      if (ric) ric(start, { timeout: 2500 });
      else window.setTimeout(start, 600);
    };
    // Start only after the page has fully loaded AND the robot is on screen
    // (on phones the robot is lower down, so the animation loads only when the visitor scrolls to it).
    const whenVisible = () => {
      const seen = new IntersectionObserver(
        ([e]) => {
          if (e.isIntersecting) {
            seen.disconnect();
            kick();
          }
        },
        { rootMargin: "100px" }
      );
      seen.observe(el);
      stopSeen = () => seen.disconnect();
    };
    let stopSeen: (() => void) | undefined;
    // Phones: wait for the visitor's first scroll/touch before even checking, so the first screen stays as fast as before.
    const phone = window.matchMedia("(max-width: 1023px)").matches;
    const firstMove = () => {
      window.removeEventListener("scroll", firstMove);
      window.removeEventListener("touchstart", firstMove);
      whenVisible();
    };
    const afterLoad = () => {
      if (!phone) return whenVisible();
      window.addEventListener("scroll", firstMove, { once: true, passive: true });
      window.addEventListener("touchstart", firstMove, { once: true, passive: true });
    };
    if (document.readyState === "complete") afterLoad();
    else window.addEventListener("load", afterLoad, { once: true });

    return () => {
      cancelled = true;
      window.removeEventListener("load", afterLoad);
      window.removeEventListener("scroll", firstMove);
      window.removeEventListener("touchstart", firstMove);
      stopSeen?.();
      io?.disconnect();
      destroy?.();
    };
  }, []);

  return (
    <div className="hh-bot">
      {/* Laptop/desktop only: start loading the still robot picture early. Phones skip it (media rule). */}
      <link rel="preload" as="image" href="/lottie/robot-poster.webp" type="image/webp" media="(min-width: 1024px)" fetchPriority="high" />
      <a href="/ai-assistant" target="_blank" rel="noopener noreferrer" aria-label="Open FDE AI Assistant in a new tab" className="hh-bot-link">
        <span className="hh-bot-glow" aria-hidden="true" />
        <span className="hh-bot-float">
          <span className="hh-bot-still" aria-hidden="true" style={{ opacity: live ? 0 : 1 }} />
          <div ref={box} className="hh-bot-live" role="img" aria-label="FDE AI Assistant robot" />
        </span>
        <span className="hh-bot-shadow" aria-hidden="true" />
      </a>
      <a href="/ai-assistant" target="_blank" rel="noopener noreferrer" className="btn btn-gold hh-bot-btn">
        Get Started
      </a>
    </div>
  );
}
