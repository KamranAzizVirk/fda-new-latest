// Animation features for Motion, loaded in the background after the page is shown.
import { domAnimation } from "motion/react";
export default domAnimation;
