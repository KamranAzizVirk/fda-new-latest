"use client";

// The AI Agent shown when the chat is opened on the HOME PAGE.
// Other pages keep the original chat window (ChatAgent.tsx).
// It talks to the same protected /api/chat endpoint: the same-site check, the size limits and the
// message limits (6 per minute, 30 per hour, 60 per day) are all enforced on the server, unchanged.

import { useEffect, useRef, useState } from "react";
import { HELLO_URL, SITE } from "@/lib/site";
import { OPEN_CHAT_EVENT } from "./FloatingActions";
import s from "./HomeChatAgent.module.css";

type Msg = { role: "user" | "assistant"; content: string };
type Problem = { kind: "limit" | "error"; text: string } | null;

const WELCOME =
  "Hi, I'm FDE AI Assistant. I help businesses automate with AI Voice Agents, AI Chat Agents and Workflow Automation. How can I help automate your business today?";

const SUGGESTIONS = ["What services do you offer?", "How does your process work?", "How much does it cost?", "Do you work with my type of business?"];

const CONTACT = `You can also reach our team on WhatsApp (${SITE.phoneDisplay}) or email ${SITE.email}.`;
const FIRST_REPLY_TIMEOUT_MS = 15_000;

function waitText(seconds: number) {
  if (!Number.isFinite(seconds) || seconds <= 0) return "later";
  if (seconds < 90) return "in about a minute";
  const minutes = Math.ceil(seconds / 60);
  if (minutes < 90) return `in about ${minutes} minutes`;
  return `in about ${Math.ceil(minutes / 60)} hours`;
}

/** Abstract AI avatar (no face of a real person). Small inline SVG, no image download. */
function Avatar({ className }: { className: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <defs>
        <radialGradient id="fdeAgentCore" cx="38%" cy="30%" r="80%">
          <stop offset="0" stopColor="#3a352d" />
          <stop offset="1" stopColor="#141312" />
        </radialGradient>
        <linearGradient id="fdeAgentGold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#f0d48a" />
          <stop offset="1" stopColor="#b8892b" />
        </linearGradient>
      </defs>
      <circle cx="32" cy="32" r="32" fill="url(#fdeAgentCore)" />
      <g className={s.orbit} fill="none" stroke="url(#fdeAgentGold)" strokeLinecap="round">
        <circle cx="32" cy="32" r="22" strokeWidth="1" opacity=".45" strokeDasharray="3 7" />
        <circle cx="54" cy="32" r="2" fill="#f0d48a" stroke="none" />
      </g>
      <path d="M32 17l3.6 9.9 9.9 3.6-9.9 3.6L32 44l-3.6-9.9-9.9-3.6 9.9-3.6z" fill="url(#fdeAgentGold)" />
      <circle cx="44.5" cy="19.5" r="1.6" fill="#f0d48a" opacity=".9" />
      <circle cx="20" cy="45" r="1.2" fill="#f0d48a" opacity=".7" />
    </svg>
  );
}

export function HomeChatAgent({ initialOpen = false }: { initialOpen?: boolean }) {
  const [open, setOpen] = useState(initialOpen);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [streaming, setStreaming] = useState("");
  const [problem, setProblem] = useState<Problem>(null);
  const sending = useRef(false); // hard guard against double submissions
  const abortRef = useRef<AbortController | null>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const onOpen = () => setOpen(true);
    window.addEventListener(OPEN_CHAT_EVENT, onOpen);
    return () => {
      window.removeEventListener(OPEN_CHAT_EVENT, onOpen);
      abortRef.current?.abort();
    };
  }, []);

  // Remember which button opened the chat, and give keyboard focus back to it when the chat closes.
  const openerRef = useRef<HTMLElement | null>(null);
  useEffect(() => {
    if (open) {
      const a = document.activeElement as HTMLElement | null;
      if (a && a !== document.body && !a.closest('[role="dialog"]')) openerRef.current = a;
    } else if (openerRef.current?.isConnected) {
      openerRef.current.focus();
      openerRef.current = null;
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    inputRef.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight });
  }, [messages, streaming, busy, problem]);

  /** Sends the conversation. `history` must end with the visitor's message. */
  async function request(history: Msg[]) {
    if (sending.current) return;
    sending.current = true;
    setBusy(true);
    setProblem(null);
    setStreaming("");

    const controller = new AbortController();
    abortRef.current = controller;
    // If no first words arrive in time, stop waiting and show a clear retry option.
    const timer = window.setTimeout(() => controller.abort(), FIRST_REPLY_TIMEOUT_MS);

    let reply = "";
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agent: "home", messages: history }),
        signal: controller.signal,
      });

      if (res.status === 429) {
        const wait = Number(res.headers.get("Retry-After"));
        setProblem({ kind: "limit", text: `You've reached the message limit for now. Please try again ${waitText(wait)}. ${CONTACT}` });
        return;
      }
      if (!res.ok || !res.body) throw new Error("unavailable");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        window.clearTimeout(timer); // the answer has started
        reply += decoder.decode(value, { stream: true });
        setStreaming(reply);
      }
      if (!reply.trim()) throw new Error("empty");
      setMessages([...history, { role: "assistant", content: reply.trim() }]);
    } catch {
      if (reply.trim()) {
        // Part of the answer arrived before the connection dropped: keep what we have.
        setMessages([...history, { role: "assistant", content: reply.trim() }]);
      } else {
        const timedOut = controller.signal.aborted;
        setProblem({
          kind: "error",
          text: `${timedOut ? "The assistant is taking too long to answer." : "The assistant could not answer right now."} Please try again. ${CONTACT}`,
        });
      }
    } finally {
      window.clearTimeout(timer);
      abortRef.current = null;
      setStreaming("");
      setBusy(false);
      sending.current = false;
    }
  }

  function send(text: string) {
    const content = text.trim();
    if (!content || sending.current) return;
    const history: Msg[] = [...messages, { role: "user", content }];
    setMessages(history);
    setInput("");
    void request(history);
  }

  // Retry re-sends the visitor's last message once. It is a normal request and is counted by the server limits.
  function retry() {
    if (sending.current || messages.length === 0 || messages[messages.length - 1].role !== "user") return;
    void request(messages);
  }

  if (!open) return null;

  return (
    <div role="dialog" aria-modal="false" aria-label="FDE AI Assistant" className={s.panel}>
      <div className={s.head}>
        <Avatar className={s.avatar} />
        <div className={s.who}>
          <p className={s.name}>
            FDE AI Assistant <span className={s.tag}>AI</span>
          </p>
          <p className={s.status}>
            <i className={s.dot} aria-hidden="true" />
            Automated AI assistant &middot; Online
          </p>
        </div>
        <button type="button" onClick={() => setOpen(false)} aria-label="Close assistant" className={s.close}>
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" aria-hidden="true">
            <path d="M6 6l12 12M18 6 6 18" />
          </svg>
        </button>
      </div>

      <div ref={listRef} className={s.log} role="log" aria-live="polite" aria-label="Conversation">
        <div className={s.row}>
          <Avatar className={s.avatarSm} />
          <div className={`${s.bubble} ${s.ai}`}>{WELCOME}</div>
        </div>

        {messages.length === 0 && !busy && (
          <div className={s.chips}>
            {SUGGESTIONS.map((q) => (
              <button key={q} type="button" onClick={() => send(q)} className={s.chip}>
                {q}
              </button>
            ))}
          </div>
        )}

        {messages.map((m, i) =>
          m.role === "user" ? (
            <div key={i} className={`${s.row} ${s.rowUser}`}>
              <div className={`${s.bubble} ${s.user}`}>{m.content}</div>
            </div>
          ) : (
            <div key={i} className={s.row}>
              <Avatar className={s.avatarSm} />
              <div className={`${s.bubble} ${s.ai}`}>{m.content}</div>
            </div>
          )
        )}

        {busy && (
          <div className={s.row}>
            <Avatar className={s.avatarSm} />
            <div className={`${s.bubble} ${s.ai}`}>
              {streaming || (
                <span className={s.thinking}>
                  <span className={s.dots} aria-hidden="true"><i /><i /><i /></span>
                  Getting your answer&hellip;
                </span>
              )}
            </div>
          </div>
        )}

        {problem && !busy && (
          <div className={s.row}>
            <Avatar className={s.avatarSm} />
            <div className={`${s.bubble} ${s.ai} ${s.notice}`} role="status">
              {problem.text}
              {problem.kind === "error" && (
                <>
                  <br />
                  <button type="button" onClick={retry} className={s.retry}>
                    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                      <path d="M20 11a8 8 0 1 0-2.3 6.3M20 5v6h-6" />
                    </svg>
                    Try again
                  </button>
                </>
              )}
            </div>
          </div>
        )}
      </div>

      <div className={s.foot}>
        <form
          className={s.form}
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
        >
          <input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            maxLength={1000}
            placeholder="Ask about automating your business..."
            aria-label="Your question"
            autoComplete="off"
            enterKeyHint="send"
            className={s.input}
          />
          <button type="submit" disabled={busy || !input.trim()} aria-label="Send" className={s.send}>
            <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" strokeWidth={2.1} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M12 19V5M5.5 11.5 12 5l6.5 6.5" />
            </svg>
          </button>
        </form>
        <p className={s.note}>
          AI answers can be wrong. For a quote,{" "}
          <a href={HELLO_URL} target="_blank" rel="noopener noreferrer">
            message us on WhatsApp
          </a>
          .
        </p>
      </div>
    </div>
  );
}
