import { TOOLS } from "@/lib/logos";

/** Display only. Logos are not links and do not imply partnership. */
export function ToolsStrip() {
  return (
    <section aria-label="Tools we build with" className="border-y border-line bg-card py-10">
      <div className="wrap">
        <p className="mb-6 text-center text-[.74rem] font-semibold uppercase tracking-[.14em] text-mut">Tools we build with</p>
        <ul className="flex flex-wrap justify-center gap-2.5">
          {TOOLS.map((t) => (
            <li
              key={t.name}
              className={`flex items-center gap-2 whitespace-nowrap rounded-full border border-line bg-bg py-2 text-[.88rem] font-medium ${t.svg ? "pl-3 pr-4" : "px-4"}`}
            >
              {t.svg && <span className="inline-flex h-5 w-5 flex-none [&>svg]:h-full [&>svg]:w-full" dangerouslySetInnerHTML={{ __html: t.svg }} />}
              {t.name}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
