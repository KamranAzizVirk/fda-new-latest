"use client";

import { LazyMotion, MotionConfig } from "motion/react";
import * as m from "motion/react-m";

// Motion's animation code is downloaded in the background, after the page is already visible.
const loadFeatures = () => import("./motionFeatures").then((r) => r.default);

/** Rises gently into view once, when scrolled to. Honors reduced-motion settings. */
export function Reveal({
  children,
  delay = 0,
  className,
}: {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}) {
  return (
    <m.div
      className={className}
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "0px 0px -60px 0px" }}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </m.div>
  );
}

/** Wrap the app so every motion element follows the visitor's "reduce motion" setting. */
export function MotionProvider({ children }: { children: React.ReactNode }) {
  return (
    <LazyMotion features={loadFeatures} strict>
      <MotionConfig reducedMotion="user">{children}</MotionConfig>
    </LazyMotion>
  );
}
