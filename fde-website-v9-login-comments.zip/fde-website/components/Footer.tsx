import Link from "next/link";
import { NAV, SITE } from "@/lib/site";
import { Logo } from "./Header";

export function Footer() {
  return (
    <footer className="pb-28 pt-12 text-[.9rem] text-mut lg:pb-40">
      <div className="wrap">
        <div className="grid gap-6 border-b border-line pb-7 lg:grid-cols-[1fr_auto] lg:items-center">
          <div>
            <Link href="/" className="inline-block text-ink"><Logo /></Link>
            <p className="mt-3 max-w-md">Forward Deployed Engineer Automation. Based in {SITE.city}, {SITE.country}. Serving clients worldwide.</p>
          </div>
          <nav aria-label="Footer" className="-my-2 flex flex-wrap gap-x-6">
            {NAV.map((item) => (
              <Link key={item.href} href={item.href} className="py-2.5 hover:text-ink">{item.label}</Link>
            ))}
            <Link href="/privacy" className="py-2.5 hover:text-ink">Privacy</Link>
          </nav>
        </div>
        <p className="mt-5 text-[.78rem] leading-relaxed">
          &copy; {new Date().getFullYear()} {SITE.name}. All rights reserved.
          <br />
          All product names and logos are trademarks of their respective owners. Their use here shows the tools we work with and does not imply endorsement or affiliation.
        </p>
      </div>
    </footer>
  );
}
