-- FDE website: "comments" table for the Home page comments box.
-- Paste ALL of this into Supabase -> SQL Editor -> New query -> Run. Safe to run again.
--
-- Rules it creates:
--   * Everyone can READ comments that you have approved (approved = true).
--   * Only logged-in (Google) users can WRITE. Name and photo are taken from their Google account,
--     so nobody can post under someone else's name.
--   * Every new comment starts hidden (approved = false). You approve it in Table Editor -> comments.
--   * A user can delete only their own comment. Nobody can approve their own comment.
--   * Max 1000 characters per comment, max 5 comments per user per hour.

create table if not exists public.comments (
  id          bigint generated always as identity primary key,
  user_id     uuid not null default auth.uid() references auth.users (id) on delete cascade,
  name        text not null default '',
  avatar_url  text,
  body        text not null check (char_length(body) between 1 and 1000),
  approved    boolean not null default false,
  created_at  timestamptz not null default now()
);

create index if not exists comments_approved_created_idx on public.comments (approved, created_at desc);
create index if not exists comments_user_created_idx on public.comments (user_id, created_at desc);

alter table public.comments enable row level security;

create or replace function public.comments_before_insert()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  meta jsonb;
  pic  text;
begin
  if auth.uid() is null then
    raise exception 'Please log in first.';
  end if;

  select raw_user_meta_data into meta from auth.users where id = auth.uid();
  pic := coalesce(meta ->> 'avatar_url', meta ->> 'picture');

  new.user_id    := auth.uid();
  new.name       := left(coalesce(nullif(meta ->> 'full_name', ''), nullif(meta ->> 'name', ''), 'Guest'), 80);
  new.avatar_url := case when pic like 'https://%' then pic else null end;
  new.body       := btrim(new.body);
  new.approved   := false;
  new.created_at := now();

  if (select count(*) from public.comments
      where user_id = auth.uid() and created_at > now() - interval '1 hour') >= 5 then
    raise exception 'Too many comments. Please try again later.';
  end if;

  return new;
end;
$$;

drop trigger if exists comments_before_insert on public.comments;
create trigger comments_before_insert
  before insert on public.comments
  for each row execute function public.comments_before_insert();

drop policy if exists "Anyone can read approved comments" on public.comments;
create policy "Anyone can read approved comments"
  on public.comments for select
  using (approved = true);

drop policy if exists "Users can read their own comments" on public.comments;
create policy "Users can read their own comments"
  on public.comments for select to authenticated
  using (user_id = auth.uid());

drop policy if exists "Logged-in users can add comments" on public.comments;
create policy "Logged-in users can add comments"
  on public.comments for insert to authenticated
  with check (user_id = auth.uid() and approved = false);

drop policy if exists "Users can delete their own comments" on public.comments;
create policy "Users can delete their own comments"
  on public.comments for delete to authenticated
  using (user_id = auth.uid());

-- No UPDATE rule on purpose: visitors can never edit or approve comments.
-- You approve from the Supabase dashboard (it is allowed to change rows).
